import { describe, it, expect } from "vitest";
import { aiAnalysisResultSchema } from "@/lib/ai/schema";
import type { AIAnalysisResult } from "@/types";

const validResult: AIAnalysisResult = {
  plant: { name: "Tomate", scientificName: "Solanum lycopersicum", confidence: 0.9 },
  diagnosis: { category: "enfermedad", name: "Tizón temprano", confidence: 0.8, severity: "media" },
  symptoms: ["Manchas marrones en las hojas"],
  possibleCauses: ["Exceso de humedad"],
  recommendations: ["Mejorar la ventilación"],
  prevention: ["Rotar los cultivos"],
  warnings: [],
  isDemoResult: false,
};

describe("aiAnalysisResultSchema", () => {
  it("acepta un resultado completo y bien formado", () => {
    const result = aiAnalysisResultSchema.safeParse(validResult);
    expect(result.success).toBe(true);
  });

  it("rechaza un resultado sin el campo 'plant'", () => {
    const { plant, ...withoutPlant } = validResult;
    const result = aiAnalysisResultSchema.safeParse(withoutPlant);
    expect(result.success).toBe(false);
  });

  it("rechaza una confianza fuera del rango 0-1", () => {
    const invalid = { ...validResult, diagnosis: { ...validResult.diagnosis, confidence: 1.5 } };
    const result = aiAnalysisResultSchema.safeParse(invalid);
    expect(result.success).toBe(false);
  });

  it("rechaza una categoría de diagnóstico que no existe", () => {
    const invalid = { ...validResult, diagnosis: { ...validResult.diagnosis, category: "categoria_inventada" } };
    const result = aiAnalysisResultSchema.safeParse(invalid);
    expect(result.success).toBe(false);
  });

  it("rechaza una severidad que no existe", () => {
    const invalid = { ...validResult, diagnosis: { ...validResult.diagnosis, severity: "extrema" } };
    const result = aiAnalysisResultSchema.safeParse(invalid);
    expect(result.success).toBe(false);
  });

  it("acepta listas vacías de síntomas, causas, recomendaciones y prevención", () => {
    const withEmptyLists = {
      ...validResult,
      symptoms: [],
      possibleCauses: [],
      recommendations: [],
      prevention: [],
    };
    const result = aiAnalysisResultSchema.safeParse(withEmptyLists);
    expect(result.success).toBe(true);
  });

  it("rechaza si isDemoResult no es booleano", () => {
    const invalid = { ...validResult, isDemoResult: "sí" };
    const result = aiAnalysisResultSchema.safeParse(invalid);
    expect(result.success).toBe(false);
  });
});
