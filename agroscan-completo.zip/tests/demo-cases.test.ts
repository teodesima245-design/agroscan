import { describe, it, expect } from "vitest";
import { demoCases, pickDemoCase } from "@/lib/demo/cases";
import { aiAnalysisResultSchema } from "@/lib/ai/schema";

describe("demoCases", () => {
  it("incluye exactamente los 4 casos definidos en el prompt maestro", () => {
    expect(demoCases.map((c) => c.id).sort()).toEqual(
      ["albahaca", "lechuga", "rosal", "tomate"].sort()
    );
  });

  it("cada caso tiene un resultado válido según el esquema de IA", () => {
    demoCases.forEach((demoCase) => {
      const validation = aiAnalysisResultSchema.safeParse(demoCase.result);
      expect(validation.success, `El caso "${demoCase.id}" no pasa la validación`).toBe(true);
    });
  });

  it("todos los casos están marcados como isDemoResult: true", () => {
    demoCases.forEach((demoCase) => {
      expect(demoCase.result.isDemoResult).toBe(true);
    });
  });
});

describe("pickDemoCase", () => {
  it("devuelve siempre el mismo caso para la misma semilla", () => {
    const first = pickDemoCase("misma-imagen.jpg");
    const second = pickDemoCase("misma-imagen.jpg");
    expect(first.id).toBe(second.id);
  });

  it("devuelve un caso válido para una semilla vacía", () => {
    const result = pickDemoCase("");
    expect(demoCases.map((c) => c.id)).toContain(result.id);
  });
});
