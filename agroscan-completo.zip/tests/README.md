# Testing de AgroScan

## Cómo correr las pruebas

```bash
npm test          # corre todas las pruebas una vez
npm run test:watch  # modo watch, útil durante el desarrollo
```

## Qué está cubierto con pruebas automáticas (Vitest)

Estas pruebas corren sin necesidad de un proyecto real de Supabase, porque
prueban la lógica pura de la aplicación:

| Archivo | Qué cubre |
|---|---|
| `auth.schemas.test.ts` | Validación de **registro** y **login**: contraseñas débiles, contraseñas que no coinciden, emails inválidos, tipos de usuario inválidos |
| `plants.schemas.test.ts` | Validación del formulario de **Mis plantas** |
| `ai-response.test.ts` | Validación de la **respuesta de IA** (punto 14 del prompt): rechaza estructuras mal formadas, confianza fuera de rango, categorías inventadas |
| `demo-cases.test.ts` | Que los 4 casos del **Demo Mode** sean válidos y estén correctamente marcados como `isDemoResult: true` |
| `utils.test.ts` | Utilidades compartidas (formato de fecha, combinación de clases, metadatos de severidad) |

## Qué NO está cubierto acá (y por qué)

El prompt original pide pruebas de **creación de análisis**, **recuperación
de análisis**, **autorización** (RLS) y **eliminación de análisis**. Estas
operaciones dependen de una base de datos Supabase real con las políticas
de RLS activas — no tiene sentido simularlas con mocks, porque lo que
realmente hay que probar es que **Postgres** aplique las políticas
correctamente, no que el código de la aplicación las respete.

Para probar eso de verdad, la forma correcta es crear un **proyecto de
Supabase separado para testing** (nunca el de producción) y escribir
pruebas de integración que usen `@supabase/supabase-js` directamente
contra ese proyecto. Una vez que tengas ese proyecto, se pueden agregar
pruebas como:

```ts
// Ejemplo de estructura para pruebas de integración (no incluidas):
// tests/integration/scans.test.ts
//
// 1. Crear dos usuarios de prueba (A y B) con supabase.auth.signUp()
// 2. Como usuario A, crear un escaneo
// 3. Verificar que el usuario A puede leerlo (creación + recuperación)
// 4. Verificar que el usuario B NO puede leerlo (autorización / RLS)
// 5. Como usuario A, eliminarlo y verificar que ya no aparece (eliminación)
```

También quedan fuera de esta carpeta, por la misma razón, las pruebas de
extremo a extremo del formulario de registro/login contra Supabase Auth
real, y las pruebas de subida de imágenes contra Supabase Storage real.

**Antes de presentar AgroScan en una feria de ciencias o de desplegarlo,
te recomendamos hacer una prueba manual completa** del flujo: registrarte,
iniciar sesión, escanear una planta, ver el resultado, editarlo en tu
historial, agregar una planta y eliminar un análisis — así confirmás que
las políticas de RLS de `/database/schema.sql` están bien aplicadas en tu
proyecto real.
