import { describe, it, expect } from "vitest";
import { cn, formatDate, severityMeta } from "@/lib/utils";

describe("cn", () => {
  it("une clases válidas con espacios", () => {
    expect(cn("a", "b", "c")).toBe("a b c");
  });

  it("descarta valores falsy", () => {
    expect(cn("a", false, null, undefined, "b")).toBe("a b");
  });

  it("devuelve una cadena vacía si no hay clases válidas", () => {
    expect(cn(false, null, undefined)).toBe("");
  });
});

describe("formatDate", () => {
  it("formatea una fecha ISO en español", () => {
    const formatted = formatDate("2026-03-15T12:00:00.000Z");
    // No fijamos el string exacto (depende del entorno/husos horarios),
    // pero sí que incluya el año y esté en formato legible.
    expect(formatted).toContain("2026");
    expect(formatted.length).toBeGreaterThan(5);
  });
});

describe("severityMeta", () => {
  it("devuelve la etiqueta correcta para cada nivel de severidad", () => {
    expect(severityMeta("baja").label).toBe("Baja");
    expect(severityMeta("media").label).toBe("Media");
    expect(severityMeta("alta").label).toBe("Alta");
    expect(severityMeta("desconocida").label).toBe("Desconocida");
  });

  it("cada nivel tiene una clase de color asociada", () => {
    (["baja", "media", "alta", "desconocida"] as const).forEach((level) => {
      expect(severityMeta(level).color).toBeTruthy();
    });
  });
});
