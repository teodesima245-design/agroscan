import { describe, it, expect } from "vitest";
import { plantSchema } from "@/lib/plants/schemas";

describe("plantSchema", () => {
  it("acepta una planta solo con nombre", () => {
    const result = plantSchema.safeParse({ name: "Tomatera del patio" });
    expect(result.success).toBe(true);
  });

  it("acepta una planta con todos los campos", () => {
    const result = plantSchema.safeParse({
      name: "Rosal",
      species: "Rosa spp.",
      notes: "Regar dos veces por semana.",
    });
    expect(result.success).toBe(true);
  });

  it("rechaza un nombre vacío", () => {
    const result = plantSchema.safeParse({ name: "" });
    expect(result.success).toBe(false);
  });

  it("rechaza un nombre demasiado largo", () => {
    const result = plantSchema.safeParse({ name: "a".repeat(81) });
    expect(result.success).toBe(false);
  });

  it("rechaza notas demasiado largas", () => {
    const result = plantSchema.safeParse({ name: "Albahaca", notes: "a".repeat(2001) });
    expect(result.success).toBe(false);
  });

  it("recorta espacios en blanco del nombre", () => {
    const result = plantSchema.safeParse({ name: "  Lechuga  " });
    expect(result.success).toBe(true);
    if (result.success) {
      expect(result.data.name).toBe("Lechuga");
    }
  });
});
