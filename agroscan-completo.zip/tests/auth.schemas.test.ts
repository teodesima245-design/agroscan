import { describe, it, expect } from "vitest";
import { registerSchema, loginSchema, resetPasswordSchema } from "@/lib/auth/schemas";

describe("registerSchema", () => {
  const validData = {
    name: "María López",
    email: "maria@example.com",
    password: "clave1234",
    confirmPassword: "clave1234",
    country: "Argentina",
    userType: "estudiante" as const,
  };

  it("acepta datos válidos", () => {
    const result = registerSchema.safeParse(validData);
    expect(result.success).toBe(true);
  });

  it("rechaza cuando las contraseñas no coinciden", () => {
    const result = registerSchema.safeParse({
      ...validData,
      confirmPassword: "otraClave123",
    });
    expect(result.success).toBe(false);
    if (!result.success) {
      expect(result.error.flatten().fieldErrors.confirmPassword).toBeDefined();
    }
  });

  it("rechaza contraseñas sin números", () => {
    const result = registerSchema.safeParse({ ...validData, password: "soloLetras", confirmPassword: "soloLetras" });
    expect(result.success).toBe(false);
  });

  it("rechaza contraseñas de menos de 8 caracteres", () => {
    const result = registerSchema.safeParse({ ...validData, password: "abc123", confirmPassword: "abc123" });
    expect(result.success).toBe(false);
  });

  it("rechaza un correo electrónico inválido", () => {
    const result = registerSchema.safeParse({ ...validData, email: "no-es-un-correo" });
    expect(result.success).toBe(false);
  });

  it("rechaza un tipo de usuario que no está en la lista permitida", () => {
    const result = registerSchema.safeParse({ ...validData, userType: "robot" });
    expect(result.success).toBe(false);
  });

  it("normaliza el correo electrónico a minúsculas", () => {
    const result = registerSchema.safeParse({ ...validData, email: "MARIA@EXAMPLE.COM" });
    expect(result.success).toBe(true);
    if (result.success) {
      expect(result.data.email).toBe("maria@example.com");
    }
  });
});

describe("loginSchema", () => {
  it("acepta credenciales válidas", () => {
    const result = loginSchema.safeParse({ email: "user@example.com", password: "cualquiera" });
    expect(result.success).toBe(true);
  });

  it("rechaza una contraseña vacía", () => {
    const result = loginSchema.safeParse({ email: "user@example.com", password: "" });
    expect(result.success).toBe(false);
  });

  it("rechaza un correo inválido", () => {
    const result = loginSchema.safeParse({ email: "no-valido", password: "algo" });
    expect(result.success).toBe(false);
  });
});

describe("resetPasswordSchema", () => {
  it("acepta un correo válido", () => {
    const result = resetPasswordSchema.safeParse({ email: "user@example.com" });
    expect(result.success).toBe(true);
  });

  it("rechaza un correo inválido", () => {
    const result = resetPasswordSchema.safeParse({ email: "invalido" });
    expect(result.success).toBe(false);
  });
});
