"use client";

import { useFormState } from "react-dom";
import Link from "next/link";
import { resetPasswordAction, type AuthActionState } from "@/lib/auth/actions";
import { Input } from "@/components/ui/Input";
import { SubmitButton } from "@/components/ui/SubmitButton";

const initialState: AuthActionState = { success: false };

export default function ResetPasswordForm() {
  const [state, formAction] = useFormState(resetPasswordAction, initialState);

  if (state.success && state.message) {
    return (
      <div
        role="status"
        className="rounded-xl2 border border-agro-200 bg-agro-50 px-5 py-4 text-center text-sm font-medium text-agro-800"
      >
        {state.message}
      </div>
    );
  }

  return (
    <form action={formAction} className="flex flex-col gap-5" noValidate>
      {state.message && !state.success && (
        <div
          role="alert"
          className="rounded-xl2 border border-red-200 bg-red-50 px-4 py-3 text-sm font-medium text-red-700"
        >
          {state.message}
        </div>
      )}

      <Input
        label="Correo electrónico"
        name="email"
        type="email"
        autoComplete="email"
        required
        error={state.fieldErrors?.email?.[0]}
      />

      <SubmitButton loadingText="Enviando enlace...">Enviar enlace de recuperación</SubmitButton>

      <p className="text-center text-sm text-agro-800/70">
        <Link href="/login" className="font-semibold text-agro-600 hover:text-agro-700">
          Volver a iniciar sesión
        </Link>
      </p>
    </form>
  );
}
