"use client";

import { useFormState } from "react-dom";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { signInAction, type AuthActionState } from "@/lib/auth/actions";
import { Input } from "@/components/ui/Input";
import { SubmitButton } from "@/components/ui/SubmitButton";

const initialState: AuthActionState = { success: false };

export default function LoginForm() {
  const [state, formAction] = useFormState(signInAction, initialState);
  const searchParams = useSearchParams();
  const redirectTo = searchParams.get("redirect") ?? "/dashboard";

  return (
    <form action={formAction} className="flex flex-col gap-5" noValidate>
      <input type="hidden" name="redirect" value={redirectTo} />

      {state.message && !state.success && (
        <div
          role="alert"
          className="rounded-xl2 border border-red-200 bg-red-50 px-4 py-3 text-sm font-medium text-red-700"
        >
          {state.message}
        </div>
      )}

      <Input
        label="Correo electrónico"
        name="email"
        type="email"
        autoComplete="email"
        required
        error={state.fieldErrors?.email?.[0]}
      />

      <Input
        label="Contraseña"
        name="password"
        type="password"
        autoComplete="current-password"
        required
        error={state.fieldErrors?.password?.[0]}
      />

      <div className="flex justify-end -mt-2">
        <Link
          href="/recuperar-password"
          className="text-sm font-medium text-tech-600 hover:text-tech-700"
        >
          Recuperar contraseña
        </Link>
      </div>

      <SubmitButton loadingText="Iniciando sesión...">Iniciar sesión</SubmitButton>

      <p className="text-center text-sm text-agro-800/70">
        ¿No tenés cuenta?{" "}
        <Link href="/registro" className="font-semibold text-agro-600 hover:text-agro-700">
          Crear cuenta
        </Link>
      </p>
    </form>
  );
}
