"use client";

import { useFormState } from "react-dom";
import Link from "next/link";
import { signUpAction, type AuthActionState } from "@/lib/auth/actions";
import { userTypeOptions } from "@/lib/auth/schemas";
import { Input } from "@/components/ui/Input";
import { Select } from "@/components/ui/Select";
import { SubmitButton } from "@/components/ui/SubmitButton";

const initialState: AuthActionState = { success: false };

// Lista breve de países hispanohablantes de América Latina + "Otro".
// Se puede ampliar sin afectar el resto de la app.
const countryOptions = [
  { value: "Argentina", label: "Argentina" },
  { value: "Bolivia", label: "Bolivia" },
  { value: "Chile", label: "Chile" },
  { value: "Colombia", label: "Colombia" },
  { value: "Costa Rica", label: "Costa Rica" },
  { value: "Cuba", label: "Cuba" },
  { value: "Ecuador", label: "Ecuador" },
  { value: "El Salvador", label: "El Salvador" },
  { value: "Guatemala", label: "Guatemala" },
  { value: "Honduras", label: "Honduras" },
  { value: "México", label: "México" },
  { value: "Nicaragua", label: "Nicaragua" },
  { value: "Panamá", label: "Panamá" },
  { value: "Paraguay", label: "Paraguay" },
  { value: "Perú", label: "Perú" },
  { value: "República Dominicana", label: "República Dominicana" },
  { value: "Uruguay", label: "Uruguay" },
  { value: "Venezuela", label: "Venezuela" },
  { value: "Otro", label: "Otro" },
];

export default function RegisterForm() {
  const [state, formAction] = useFormState(signUpAction, initialState);

  if (state.success && state.message) {
    return (
      <div
        role="status"
        className="rounded-xl2 border border-agro-200 bg-agro-50 px-5 py-4 text-center text-sm font-medium text-agro-800"
      >
        {state.message}
      </div>
    );
  }

  return (
    <form action={formAction} className="flex flex-col gap-5" noValidate>
      {state.message && !state.success && (
        <div
          role="alert"
          className="rounded-xl2 border border-red-200 bg-red-50 px-4 py-3 text-sm font-medium text-red-700"
        >
          {state.message}
        </div>
      )}

      <Input
        label="Nombre"
        name="name"
        type="text"
        autoComplete="name"
        required
        error={state.fieldErrors?.name?.[0]}
      />

      <Input
        label="Correo electrónico"
        name="email"
        type="email"
        autoComplete="email"
        required
        error={state.fieldErrors?.email?.[0]}
      />

      <Input
        label="Contraseña"
        name="password"
        type="password"
        autoComplete="new-password"
        required
        hint="Mínimo 8 caracteres, con al menos una letra y un número."
        error={state.fieldErrors?.password?.[0]}
      />

      <Input
        label="Confirmar contraseña"
        name="confirmPassword"
        type="password"
        autoComplete="new-password"
        required
        error={state.fieldErrors?.confirmPassword?.[0]}
      />

      <Select
        label="País"
        name="country"
        placeholder="Seleccioná tu país"
        options={countryOptions}
        required
        error={state.fieldErrors?.country?.[0]}
      />

      <Select
        label="Tipo de usuario"
        name="userType"
        placeholder="¿Cómo te describís?"
        options={userTypeOptions}
        required
        error={state.fieldErrors?.userType?.[0]}
      />

      <SubmitButton loadingText="Creando cuenta...">Crear cuenta</SubmitButton>

      <p className="text-center text-sm text-agro-800/70">
        ¿Ya tenés cuenta?{" "}
        <Link href="/login" className="font-semibold text-agro-600 hover:text-agro-700">
          Iniciar sesión
        </Link>
      </p>
    </form>
  );
}
