"use client";

import { useFormStatus } from "react-dom";
import { Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";

interface SubmitButtonProps {
  children: React.ReactNode;
  loadingText?: string;
  variant?: "primary" | "tech";
  className?: string;
}

/** Botón que se deshabilita y muestra un spinner mientras la Server Action está en curso. */
export function SubmitButton({
  children,
  loadingText = "Enviando...",
  variant = "primary",
  className,
}: SubmitButtonProps) {
  const { pending } = useFormStatus();

  return (
    <button
      type="submit"
      disabled={pending}
      aria-busy={pending}
      className={cn(
        variant === "primary" ? "btn-primary" : "btn-tech",
        "w-full disabled:opacity-70 disabled:cursor-not-allowed",
        className
      )}
    >
      {pending && <Loader2 size={18} className="animate-spin" aria-hidden="true" />}
      {pending ? loadingText : children}
    </button>
  );
}
