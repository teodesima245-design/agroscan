import { ShieldAlert, Leaf, Globe2 } from "lucide-react";

export default function AboutProject() {
  return (
    <section id="proyecto" className="bg-agro-50/60 py-20">
      <div className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto">
          <h2 className="font-display text-3xl font-bold text-agro-900 sm:text-4xl">
            Nuestro proyecto
          </h2>
          <p className="mt-4 text-agro-800/70">
            AgroScan es un proyecto 100% gratuito, pensado para estudiantes,
            familias, jardineros, agricultores y pequeños productores de
            América Latina.
          </p>
        </div>

        <div className="mt-12 grid gap-6 sm:grid-cols-3">
          <div className="card p-6 text-center">
            <Leaf className="mx-auto text-agro-500" size={28} aria-hidden="true" />
            <h3 className="mt-3 font-semibold text-agro-900">Cuidado responsable</h3>
            <p className="mt-2 text-sm text-agro-800/70">
              Priorizamos prevención y buenas prácticas agroecológicas antes
              que soluciones químicas.
            </p>
          </div>
          <div className="card p-6 text-center">
            <Globe2 className="mx-auto text-agro-500" size={28} aria-hidden="true" />
            <h3 className="mt-3 font-semibold text-agro-900">Pensado para Latinoamérica</h3>
            <p className="mt-2 text-sm text-agro-800/70">
              Cultivos y plantas ornamentales comunes de la región, en español
              latinoamericano.
            </p>
          </div>
          <div className="card p-6 text-center">
            <ShieldAlert className="mx-auto text-agro-500" size={28} aria-hidden="true" />
            <h3 className="mt-3 font-semibold text-agro-900">Transparencia</h3>
            <p className="mt-2 text-sm text-agro-800/70">
              Mostramos siempre el nivel de confianza y nunca presentamos un
              resultado como diagnóstico definitivo.
            </p>
          </div>
        </div>

        {/* Aviso obligatorio sobre la IA (punto 36 del prompt maestro) */}
        <div
          role="note"
          className="mt-12 rounded-xl2 border border-earth-400/40 bg-earth-50 p-6 text-sm text-earth-700"
        >
          <strong className="block font-semibold text-earth-700 mb-1">
            Aviso sobre la inteligencia artificial
          </strong>
          AgroScan utiliza inteligencia artificial para generar estimaciones
          orientativas a partir de imágenes. Los resultados pueden contener
          errores y no constituyen un diagnóstico profesional. Ante problemas
          graves o dudas, consultá a un profesional especializado.
        </div>
      </div>
    </section>
  );
}
