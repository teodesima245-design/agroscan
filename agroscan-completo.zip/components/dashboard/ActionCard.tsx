import Link from "next/link";
import type { LucideIcon } from "lucide-react";

interface ActionCardProps {
  href: string;
  icon: LucideIcon;
  title: string;
  description: string;
  accent?: "agro" | "tech" | "earth";
}

const accentClasses = {
  agro: "bg-agro-100 text-agro-600 group-hover:bg-agro-500 group-hover:text-white",
  tech: "bg-tech-100 text-tech-600 group-hover:bg-tech-500 group-hover:text-white",
  earth: "bg-earth-100 text-earth-500 group-hover:bg-earth-500 group-hover:text-white",
};

export default function ActionCard({
  href,
  icon: Icon,
  title,
  description,
  accent = "agro",
}: ActionCardProps) {
  return (
    <Link href={href} className="card group flex flex-col gap-3 p-6">
      <span
        className={`flex h-12 w-12 items-center justify-center rounded-xl2 transition-colors ${accentClasses[accent]}`}
      >
        <Icon size={24} aria-hidden="true" />
      </span>
      <h3 className="font-display text-lg font-bold text-agro-900">{title}</h3>
      <p className="text-sm text-agro-800/70">{description}</p>
    </Link>
  );
}
