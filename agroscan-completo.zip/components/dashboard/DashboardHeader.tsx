import Link from "next/link";
import { Leaf, LogOut, User as UserIcon } from "lucide-react";
import { signOutAction } from "@/lib/auth/actions";

interface DashboardHeaderProps {
  userName: string;
}

const navLinks = [
  { href: "/dashboard", label: "Inicio" },
  { href: "/escanear", label: "Escanear" },
  { href: "/historial", label: "Mi historial" },
  { href: "/mis-plantas", label: "Mis plantas" },
  { href: "/compartir", label: "Compartir" },
];

export default function DashboardHeader({ userName }: DashboardHeaderProps) {
  return (
    <header className="sticky top-0 z-50 border-b border-agro-100 bg-white/90 backdrop-blur">
      <nav
        aria-label="Navegación del panel"
        className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3 sm:px-6 lg:px-8"
      >
        <Link href="/dashboard" className="flex items-center gap-2 text-agro-700 font-display font-bold text-lg">
          <span className="flex h-9 w-9 items-center justify-center rounded-xl2 bg-agro-500 text-white">
            <Leaf size={20} aria-hidden="true" />
          </span>
          AgroScan
        </Link>

        <ul className="hidden md:flex items-center gap-6 text-sm font-medium text-agro-800">
          {navLinks.map((link) => (
            <li key={link.href}>
              <Link href={link.href} className="hover:text-agro-500 transition-colors">
                {link.label}
              </Link>
            </li>
          ))}
        </ul>

        <div className="flex items-center gap-3">
          <Link
            href="/perfil"
            className="hidden sm:flex items-center gap-2 rounded-xl2 border border-agro-200 px-3 py-2 text-sm font-medium text-agro-800 hover:bg-agro-50"
          >
            <UserIcon size={16} aria-hidden="true" />
            {userName}
          </Link>
          <form action={signOutAction}>
            <button
              type="submit"
              className="flex h-11 w-11 items-center justify-center rounded-xl2 border border-agro-200 text-agro-700 hover:bg-agro-50"
              aria-label="Cerrar sesión"
              title="Cerrar sesión"
            >
              <LogOut size={18} aria-hidden="true" />
            </button>
          </form>
        </div>
      </nav>
    </header>
  );
}
