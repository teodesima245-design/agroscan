"use client";

import { useState } from "react";
import { Sparkles, AlertTriangle, Search, Gauge, Eye, Brain, Sprout, ShieldCheck, Leaf } from "lucide-react";
import { demoCases } from "@/lib/demo/cases";
import { severityMeta } from "@/lib/utils";

export default function DemoModeView() {
  const [selectedId, setSelectedId] = useState(demoCases[0].id);
  const selected = demoCases.find((c) => c.id === selectedId) ?? demoCases[0];
  const { result } = selected;
  const severity = severityMeta(result.diagnosis.severity);
  const confidencePercent = Math.round(result.diagnosis.confidence * 100);

  return (
    <div className="mx-auto max-w-3xl">
      {/* Selector de casos */}
      <div className="flex flex-wrap justify-center gap-2">
        {demoCases.map((c) => (
          <button
            key={c.id}
            type="button"
            onClick={() => setSelectedId(c.id)}
            className={`min-h-[44px] rounded-xl2 border px-5 text-sm font-semibold transition-colors ${
              selectedId === c.id
                ? "border-agro-500 bg-agro-500 text-white"
                : "border-agro-200 bg-white text-agro-700 hover:bg-agro-50"
            }`}
          >
            {c.label}
          </button>
        ))}
      </div>

      {/* Resultado de demostración */}
      <div className="mt-8">
        <div className="flex items-center justify-center gap-2 rounded-xl2 bg-earth-100 px-4 py-2 text-sm font-bold uppercase tracking-wide text-earth-700">
          <Sparkles size={16} aria-hidden="true" />
          Resultado de demostración — no proviene de un análisis real de IA
        </div>

        <div className="mt-6 flex aspect-video w-full items-center justify-center rounded-xl2 border border-agro-100 bg-agro-100 sm:aspect-[21/9]">
          <span className="text-6xl" aria-hidden="true">
            {selected.label.split(" ")[0]}
          </span>
        </div>

        <section className="card mt-6 p-6">
          <SectionHeader icon={Leaf} title="Planta identificada" />
          <p className="mt-2 font-display text-xl font-bold text-agro-900">{result.plant.name}</p>
          <p className="text-sm italic text-agro-800/60">{result.plant.scientificName}</p>
        </section>

        <section className="card mt-4 p-6">
          <SectionHeader icon={Search} title="Posible problema" />
          <p className="mt-2 font-display text-xl font-bold text-agro-900">{result.diagnosis.name}</p>
        </section>

        <section className="card mt-4 p-6">
          <SectionHeader icon={Gauge} title="Severidad" />
          <div className="mt-3 flex flex-wrap items-center gap-2">
            <span className={`rounded-full px-4 py-1.5 text-sm font-bold ${severity.color}`}>
              {severity.label}
            </span>
            <span className="rounded-full bg-tech-100 px-4 py-1.5 text-sm font-bold text-tech-700">
              Confianza: {confidencePercent}%
            </span>
          </div>
        </section>

        {result.symptoms.length > 0 && (
          <section className="card mt-4 p-6">
            <SectionHeader icon={Eye} title="Síntomas observados" />
            <ul className="mt-2 list-disc space-y-1 pl-5 text-sm text-agro-800/80">
              {result.symptoms.map((s, i) => (
                <li key={i}>{s}</li>
              ))}
            </ul>
          </section>
        )}

        {result.possibleCauses.length > 0 && (
          <section className="card mt-4 p-6">
            <SectionHeader icon={Brain} title="Posibles causas" />
            <ul className="mt-2 list-disc space-y-1 pl-5 text-sm text-agro-800/80">
              {result.possibleCauses.map((c, i) => (
                <li key={i}>{c}</li>
              ))}
            </ul>
          </section>
        )}

        {result.recommendations.length > 0 && (
          <section className="card mt-4 p-6">
            <SectionHeader icon={Sprout} title="Recomendaciones" />
            <ul className="mt-2 list-disc space-y-1 pl-5 text-sm text-agro-800/80">
              {result.recommendations.map((r, i) => (
                <li key={i}>{r}</li>
              ))}
            </ul>
          </section>
        )}

        {result.prevention.length > 0 && (
          <section className="card mt-4 p-6">
            <SectionHeader icon={ShieldCheck} title="Prevención" />
            <ul className="mt-2 list-disc space-y-1 pl-5 text-sm text-agro-800/80">
              {result.prevention.map((p, i) => (
                <li key={i}>{p}</li>
              ))}
            </ul>
          </section>
        )}

        <div
          role="note"
          className="mt-6 flex items-start gap-2 rounded-xl2 border border-earth-400/40 bg-earth-50 px-5 py-4 text-xs text-earth-700"
        >
          <AlertTriangle size={16} className="mt-0.5 shrink-0" aria-hidden="true" />
          Este es un caso predefinido para demostrar AgroScan sin necesidad
          de conexión a una inteligencia artificial real. No representa el
          análisis de ninguna fotografía enviada.
        </div>
      </div>
    </div>
  );
}

function SectionHeader({
  icon: Icon,
  title,
}: {
  icon: React.ComponentType<{ size?: number; className?: string; "aria-hidden"?: boolean }>;
  title: string;
}) {
  return (
    <div className="flex items-center gap-2 text-agro-800/60">
      <Icon size={16} aria-hidden="true" />
      <p className="text-sm font-semibold uppercase tracking-wide">{title}</p>
    </div>
  );
}
