"use client";

import { useMemo, useState, useTransition } from "react";
import Link from "next/link";
import { Search, Trash2, ImageOff, Sparkles, History } from "lucide-react";
import { deleteScanAction } from "@/lib/scans/actions";
import { severityMeta, formatDate } from "@/lib/utils";
import type { Scan, SeverityLevel } from "@/types";

interface HistorialListProps {
  scans: (Scan & { thumbnailUrl: string | null })[];
}

const severityFilters: { value: SeverityLevel | "todas"; label: string }[] = [
  { value: "todas", label: "Todas" },
  { value: "baja", label: "Baja" },
  { value: "media", label: "Media" },
  { value: "alta", label: "Alta" },
];

export default function HistorialList({ scans }: HistorialListProps) {
  const [query, setQuery] = useState("");
  const [severityFilter, setSeverityFilter] = useState<SeverityLevel | "todas">("todas");
  const [items, setItems] = useState(scans);
  const [pendingDeleteId, setPendingDeleteId] = useState<string | null>(null);
  const [isPending, startTransition] = useTransition();

  const filtered = useMemo(() => {
    return items.filter((scan) => {
      const matchesQuery =
        query.trim().length === 0 ||
        scan.plantName.toLowerCase().includes(query.toLowerCase()) ||
        scan.diagnosisName.toLowerCase().includes(query.toLowerCase());
      const matchesSeverity = severityFilter === "todas" || scan.severity === severityFilter;
      return matchesQuery && matchesSeverity;
    });
  }, [items, query, severityFilter]);

  const handleDelete = (scanId: string) => {
    setPendingDeleteId(null);
    startTransition(async () => {
      const result = await deleteScanAction(scanId);
      if (result.success) {
        setItems((prev) => prev.filter((s) => s.id !== scanId));
      }
    });
  };

  if (scans.length === 0) {
    return (
      <div className="card flex flex-col items-center gap-3 p-10 text-center">
        <History size={32} className="text-agro-300" aria-hidden="true" />
        <p className="font-semibold text-agro-900">Todavía no hiciste ningún análisis</p>
        <Link href="/escanear" className="btn-primary mt-2">
          Escanear tu primera planta
        </Link>
      </div>
    );
  }

  return (
    <div>
      {/* Búsqueda y filtro */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
        <div className="relative flex-1">
          <Search
            size={18}
            className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-agro-400"
            aria-hidden="true"
          />
          <input
            type="search"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Buscar por planta o problema..."
            aria-label="Buscar en el historial"
            className="min-h-[44px] w-full rounded-xl2 border border-agro-200 bg-white py-2.5 pl-10 pr-4 text-agro-900 focus:outline-none focus:ring-2 focus:ring-tech-500"
          />
        </div>

        <div className="flex gap-2 overflow-x-auto">
          {severityFilters.map((f) => (
            <button
              key={f.value}
              type="button"
              onClick={() => setSeverityFilter(f.value)}
              className={`min-h-[44px] shrink-0 rounded-xl2 border px-4 text-sm font-semibold transition-colors ${
                severityFilter === f.value
                  ? "border-agro-500 bg-agro-500 text-white"
                  : "border-agro-200 bg-white text-agro-700 hover:bg-agro-50"
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>
      </div>

      {filtered.length === 0 ? (
        <p className="mt-8 text-center text-sm text-agro-800/60">
          No encontramos análisis que coincidan con tu búsqueda.
        </p>
      ) : (
        <ul className="mt-6 flex flex-col gap-3">
          {filtered.map((scan) => {
            const severity = severityMeta(scan.severity);
            return (
              <li key={scan.id} className="card flex items-center gap-4 p-4">
                <Link href={`/resultado/${scan.id}`} className="shrink-0">
                  <div className="h-16 w-16 overflow-hidden rounded-xl bg-agro-100">
                    {scan.thumbnailUrl ? (
                      // eslint-disable-next-line @next/next/no-img-element
                      <img
                        src={scan.thumbnailUrl}
                        alt={`Miniatura del análisis de ${scan.plantName}`}
                        className="h-full w-full object-cover"
                      />
                    ) : (
                      <div className="flex h-full w-full items-center justify-center text-agro-300">
                        <ImageOff size={20} aria-hidden="true" />
                      </div>
                    )}
                  </div>
                </Link>

                <Link href={`/resultado/${scan.id}`} className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <p className="truncate font-semibold text-agro-900">{scan.plantName}</p>
                    {scan.isDemoResult && (
                      <Sparkles size={14} className="shrink-0 text-earth-500" aria-hidden="true" />
                    )}
                  </div>
                  <p className="truncate text-sm text-agro-800/70">{scan.diagnosisName}</p>
                  <div className="mt-1 flex items-center gap-2">
                    <span className={`rounded-full px-2 py-0.5 text-xs font-bold ${severity.color}`}>
                      {severity.label}
                    </span>
                    <span className="text-xs text-agro-800/50">{formatDate(scan.createdAt)}</span>
                  </div>
                </Link>

                {pendingDeleteId === scan.id ? (
                  <div className="flex shrink-0 flex-col gap-1 sm:flex-row">
                    <button
                      type="button"
                      onClick={() => handleDelete(scan.id)}
                      disabled={isPending}
                      className="rounded-xl2 bg-red-600 px-3 py-2 text-xs font-bold text-white hover:bg-red-700 disabled:opacity-60"
                    >
                      Confirmar
                    </button>
                    <button
                      type="button"
                      onClick={() => setPendingDeleteId(null)}
                      className="rounded-xl2 border border-agro-200 px-3 py-2 text-xs font-semibold text-agro-700"
                    >
                      Cancelar
                    </button>
                  </div>
                ) : (
                  <button
                    type="button"
                    onClick={() => setPendingDeleteId(scan.id)}
                    aria-label={`Eliminar análisis de ${scan.plantName}`}
                    className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl2 border border-agro-200 text-agro-500 hover:bg-red-50 hover:text-red-600"
                  >
                    <Trash2 size={18} aria-hidden="true" />
                  </button>
                )}
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}
