import Link from "next/link";
import { Leaf } from "lucide-react";

export default function Footer() {
  return (
    <footer className="mt-auto border-t border-agro-100 bg-white">
      <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
        <div className="flex flex-col items-center gap-4 text-center sm:flex-row sm:justify-between sm:text-left">
          <div className="flex items-center gap-2 text-agro-700 font-display font-bold">
            <Leaf size={18} aria-hidden="true" />
            AgroScan: Guardianes Ecológicos
          </div>
          <p className="text-sm text-agro-800/60">
            Proyecto educativo y gratuito · Escaneá. Detectá. Protegé.
          </p>
        </div>

        <nav aria-label="Enlaces del pie de página" className="mt-6 flex flex-wrap justify-center gap-x-6 gap-y-2 text-sm text-agro-800/70 sm:justify-start">
          <Link href="/privacidad" className="hover:text-agro-500">
            Privacidad
          </Link>
          <Link href="/#proyecto" className="hover:text-agro-500">
            Nuestro proyecto
          </Link>
          <Link href="/demo" className="hover:text-agro-500">
            Modo demostración
          </Link>
        </nav>
      </div>
    </footer>
  );
}
