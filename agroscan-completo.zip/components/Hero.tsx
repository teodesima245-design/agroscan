import Link from "next/link";
import { ScanLine, Sprout } from "lucide-react";

export default function Hero() {
  return (
    <section className="relative overflow-hidden bg-gradient-to-b from-agro-50 to-white">
      <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 sm:py-24 lg:px-8">
        <div className="grid items-center gap-12 lg:grid-cols-2">
          {/* Texto principal */}
          <div className="animate-fade-up">
            <span className="inline-flex items-center gap-2 rounded-full bg-agro-100 px-4 py-1.5 text-sm font-semibold text-agro-700">
              <Sprout size={16} aria-hidden="true" />
              Escaneá. Detectá. Protegé.
            </span>

            <h1 className="mt-6 font-display text-4xl font-bold leading-tight text-agro-900 sm:text-5xl">
              Detectá problemas en tus plantas con{" "}
              <span className="text-agro-500">inteligencia artificial.</span>
            </h1>

            <p className="mt-6 text-lg text-agro-800/80 max-w-xl">
              Subí una fotografía de tu planta y AgroScan analizará posibles
              enfermedades, plagas y síntomas para ayudarte a cuidarla.
            </p>

            <div className="mt-8 flex flex-col gap-3 sm:flex-row">
              <Link href="/escanear" className="btn-primary">
                <ScanLine size={20} aria-hidden="true" />
                Escanear una planta
              </Link>
              <Link href="/registro" className="btn-secondary">
                Crear cuenta
              </Link>
            </div>

            <p className="mt-6 text-sm text-agro-700/70">
              100% gratuita · Sin suscripciones · Pensada para América Latina
            </p>
          </div>

          {/* Ilustración / mockup del escáner */}
          <div className="relative animate-fade-up" style={{ animationDelay: "0.15s" }}>
            <div className="relative mx-auto max-w-sm rounded-xl2 border border-agro-100 bg-white p-4 shadow-xl">
              <div className="relative overflow-hidden rounded-xl bg-agro-100 aspect-[4/5] flex items-center justify-center">
                <Sprout size={72} className="text-agro-400" aria-hidden="true" />
                {/* Línea de escaneo animada */}
                <div
                  className="absolute inset-x-0 top-0 h-1 bg-tech-500/80 shadow-[0_0_12px_2px_rgba(36,120,240,0.6)] animate-scan-line"
                  aria-hidden="true"
                />
              </div>
              <div className="mt-4 flex items-center justify-between text-sm">
                <span className="font-semibold text-agro-800">
                  Analizando tu planta...
                </span>
                <span className="flex h-6 w-6 items-center justify-center rounded-full bg-tech-100 text-tech-600 text-xs font-bold">
                  IA
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
