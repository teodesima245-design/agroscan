"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { Camera, Upload, ImageOff, ScanLine, RotateCcw, Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";
import { useUser } from "@/hooks/useUser";
import { validatePlantImage } from "@/services/storage/validateImage";
import { uploadPlantImage } from "@/services/storage/uploadPlantImage";
import { createScanAction } from "@/lib/scans/actions";
import { getUserPlantsAction } from "@/lib/plants/actions";
import { ACCEPTED_IMAGE_FORMATS } from "@/lib/constants";
import type { ScanStage } from "@/types";

const stageMessages: Partial<Record<ScanStage, string>> = {
  validando: "Validando la imagen...",
  subiendo: "Subiendo tu imagen...",
  analizando: "Analizando tu planta...",
  preparando_resultado: "Preparando el resultado...",
};

export default function PlantScanner() {
  const router = useRouter();
  const { user } = useUser();
  const [preview, setPreview] = useState<string | null>(null);
  const [file, setFile] = useState<File | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [stage, setStage] = useState<ScanStage>("idle");
  const [userPlants, setUserPlants] = useState<{ id: string; name: string }[]>([]);
  const [selectedPlantId, setSelectedPlantId] = useState<string>("");
  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    getUserPlantsAction().then((plants) => setUserPlants(plants));
  }, []);

  const isBusy = stage !== "idle" && stage !== "error" && stage !== "completo";

  const handleFile = useCallback(async (selected: File | undefined) => {
    if (!selected) return;

    setError(null);
    setStage("validando");

    const result = await validatePlantImage(selected);

    if (!result.valid) {
      setError(result.errorMessage ?? "La imagen no es válida.");
      setFile(null);
      setPreview(null);
      setStage("error");
      return;
    }

    setFile(selected);
    setPreview(URL.createObjectURL(selected));
    setStage("idle");
  }, []);

  const handleDrop = useCallback(
    (e: React.DragEvent<HTMLDivElement>) => {
      e.preventDefault();
      setIsDragging(false);
      handleFile(e.dataTransfer.files?.[0]);
    },
    [handleFile]
  );

  const reset = () => {
    setFile(null);
    setPreview(null);
    setError(null);
    setStage("idle");
  };

  const handleAnalyze = async () => {
    if (!file) return;

    if (!user) {
      setError("Tu sesión expiró. Volvé a iniciar sesión para continuar.");
      setStage("error");
      return;
    }

    setError(null);
    setStage("subiendo");

    const uploadResult = await uploadPlantImage(file, user.id);

    if (!uploadResult.success || !uploadResult.path) {
      setError(uploadResult.errorMessage ?? "Error de almacenamiento. Intentá nuevamente.");
      setStage("error");
      return;
    }

    setStage("analizando");

    const scanResult = await createScanAction(uploadResult.path, selectedPlantId || null);

    if (!scanResult.success || !scanResult.scanId) {
      setError(scanResult.message ?? "Error de IA. Intentá nuevamente.");
      setStage("error");
      return;
    }

    setStage("preparando_resultado");
    router.push(`/resultado/${scanResult.scanId}`);
  };

  return (
    <div className="mx-auto max-w-xl">
      {!preview ? (
        <div
          onDragOver={(e) => {
            e.preventDefault();
            setIsDragging(true);
          }}
          onDragLeave={() => setIsDragging(false)}
          onDrop={handleDrop}
          className={cn(
            "flex flex-col items-center justify-center gap-4 rounded-xl2 border-2 border-dashed p-10 text-center transition-colors",
            isDragging ? "border-tech-500 bg-tech-50" : "border-agro-200 bg-agro-50/50"
          )}
        >
          <span className="flex h-16 w-16 items-center justify-center rounded-full bg-agro-100 text-agro-500">
            {stage === "validando" ? (
              <Loader2 size={32} className="animate-spin" aria-hidden="true" />
            ) : (
              <ScanLine size={32} aria-hidden="true" />
            )}
          </span>
          <div>
            <p className="font-semibold text-agro-900">
              {stage === "validando" ? "Validando la imagen..." : "Arrastrá una imagen acá"}
            </p>
            <p className="mt-1 text-sm text-agro-800/60">
              o elegí una opción abajo. Formatos: JPG, PNG, WEBP. Máximo 10MB.
            </p>
          </div>

          <div className="mt-2 flex flex-col gap-3 sm:flex-row">
            <button
              type="button"
              onClick={() => cameraInputRef.current?.click()}
              disabled={stage === "validando"}
              className="btn-primary disabled:opacity-60"
            >
              <Camera size={20} aria-hidden="true" />
              Tomar fotografía
            </button>
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              disabled={stage === "validando"}
              className="btn-secondary disabled:opacity-60"
            >
              <Upload size={20} aria-hidden="true" />
              Subir imagen
            </button>
          </div>

          {/* Input de cámara: capture="environment" abre la cámara trasera en móviles */}
          <input
            ref={cameraInputRef}
            type="file"
            accept={ACCEPTED_IMAGE_FORMATS.join(",")}
            capture="environment"
            className="sr-only"
            onChange={(e) => handleFile(e.target.files?.[0])}
          />
          <input
            ref={fileInputRef}
            type="file"
            accept={ACCEPTED_IMAGE_FORMATS.join(",")}
            className="sr-only"
            onChange={(e) => handleFile(e.target.files?.[0])}
          />

          {error && (
            <div
              role="alert"
              className="mt-2 flex items-start gap-2 rounded-xl2 border border-red-200 bg-red-50 px-4 py-3 text-sm font-medium text-red-700"
            >
              <ImageOff size={18} className="mt-0.5 shrink-0" aria-hidden="true" />
              {error}
            </div>
          )}
        </div>
      ) : (
        <div className="card p-4">
          <div className="relative overflow-hidden rounded-xl">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={preview}
              alt="Vista previa de la planta a analizar"
              className="w-full aspect-square object-cover"
            />
            {isBusy && (
              <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 bg-black/50 text-white">
                <Loader2 size={32} className="animate-spin" aria-hidden="true" />
                <p className="font-medium">{stageMessages[stage]}</p>
              </div>
            )}
          </div>

          {error && (
            <div
              role="alert"
              className="mt-4 flex items-start gap-2 rounded-xl2 border border-red-200 bg-red-50 px-4 py-3 text-sm font-medium text-red-700"
            >
              <ImageOff size={18} className="mt-0.5 shrink-0" aria-hidden="true" />
              {error}
            </div>
          )}

          {userPlants.length > 0 && (
            <div className="mt-4">
              <label htmlFor="plant-select" className="text-sm font-semibold text-agro-900">
                Asociar a una planta (opcional)
              </label>
              <select
                id="plant-select"
                value={selectedPlantId}
                onChange={(e) => setSelectedPlantId(e.target.value)}
                disabled={isBusy}
                className="mt-1.5 min-h-[44px] w-full rounded-xl2 border border-agro-200 bg-white px-4 py-2.5 text-agro-900 focus:outline-none focus:ring-2 focus:ring-tech-500"
              >
                <option value="">Sin asociar</option>
                {userPlants.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name}
                  </option>
                ))}
              </select>
            </div>
          )}

          <div className="mt-4 flex flex-col gap-3 sm:flex-row">
            <button
              type="button"
              className="btn-tech flex-1 disabled:opacity-60"
              onClick={handleAnalyze}
              disabled={isBusy}
            >
              <ScanLine size={20} aria-hidden="true" />
              Analizar imagen
            </button>
            <button
              type="button"
              onClick={reset}
              disabled={isBusy}
              className="btn-secondary disabled:opacity-60"
            >
              <RotateCcw size={20} aria-hidden="true" />
              Cambiar imagen
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
