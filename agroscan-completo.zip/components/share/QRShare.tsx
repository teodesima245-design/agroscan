"use client";

import { useState } from "react";
import { QRCodeSVG } from "qrcode.react";
import { Copy, Check, Leaf } from "lucide-react";

interface QRShareProps {
  appUrl: string;
}

export default function QRShare({ appUrl }: QRShareProps) {
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(appUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // Si el navegador bloquea el portapapeles, no rompemos la UI:
      // el usuario igual puede seleccionar y copiar la URL manualmente.
    }
  };

  return (
    <div className="mx-auto max-w-md">
      {/* Tarjeta pensada para proyectarse o imprimirse en una feria de ciencias */}
      <div className="card flex flex-col items-center gap-6 border-2 border-agro-200 p-10 text-center">
        <div className="flex items-center gap-2 text-agro-700 font-display font-bold text-xl">
          <span className="flex h-10 w-10 items-center justify-center rounded-xl2 bg-agro-500 text-white">
            <Leaf size={22} aria-hidden="true" />
          </span>
          AgroScan
        </div>

        <div className="rounded-xl2 border-4 border-agro-100 bg-white p-4">
          <QRCodeSVG
            value={appUrl}
            size={220}
            level="H"
            marginSize={0}
            fgColor="#264f22"
            bgColor="#ffffff"
          />
        </div>

        <div>
          <p className="font-display text-lg font-bold text-agro-900">
            Escaneá el código QR para conocer AgroScan.
          </p>
          <p className="mt-1 text-sm text-agro-800/60">"Escaneá. Detectá. Protegé."</p>
        </div>

        <button type="button" onClick={handleCopy} className="btn-secondary w-full">
          {copied ? <Check size={18} aria-hidden="true" /> : <Copy size={18} aria-hidden="true" />}
          {copied ? "¡Enlace copiado!" : "Copiar enlace"}
        </button>

        <p className="break-all text-xs text-agro-800/50">{appUrl}</p>
      </div>
    </div>
  );
}
