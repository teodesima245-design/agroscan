import { Camera, ScanLine, BrainCircuit, HeartHandshake } from "lucide-react";

const steps = [
  {
    number: "01",
    title: "Fotografiar",
    description: "Tomá una fotografía clara de la planta.",
    icon: Camera,
  },
  {
    number: "02",
    title: "Escanear",
    description: "Subí la imagen a AgroScan.",
    icon: ScanLine,
  },
  {
    number: "03",
    title: "Analizar",
    description: "La inteligencia artificial analiza las características visibles.",
    icon: BrainCircuit,
  },
  {
    number: "04",
    title: "Cuidar",
    description: "Recibí información y recomendaciones.",
    icon: HeartHandshake,
  },
];

export default function HowItWorks() {
  return (
    <section id="como-funciona" className="mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:px-8">
      <div className="text-center max-w-2xl mx-auto">
        <h2 className="font-display text-3xl font-bold text-agro-900 sm:text-4xl">
          Cómo funciona
        </h2>
        <p className="mt-4 text-agro-800/70">
          Cuidar tus plantas nunca fue tan sencillo. Cuatro pasos y listo.
        </p>
      </div>

      <div className="mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
        {steps.map((step) => {
          const Icon = step.icon;
          return (
            <div key={step.number} className="card p-6 text-left">
              <div className="flex items-center justify-between">
                <span className="flex h-12 w-12 items-center justify-center rounded-xl2 bg-agro-100 text-agro-600">
                  <Icon size={24} aria-hidden="true" />
                </span>
                <span className="font-display text-3xl font-bold text-agro-100">
                  {step.number}
                </span>
              </div>
              <h3 className="mt-4 font-display text-lg font-bold text-agro-900">
                {step.title}
              </h3>
              <p className="mt-2 text-sm text-agro-800/70">{step.description}</p>
            </div>
          );
        })}
      </div>
    </section>
  );
}
