import Link from "next/link";
import { Leaf, Menu } from "lucide-react";

const navLinks = [
  { href: "/", label: "Inicio" },
  { href: "/#como-funciona", label: "Cómo funciona" },
  { href: "/#proyecto", label: "Nuestro proyecto" },
];

export default function Header() {
  return (
    <header className="sticky top-0 z-50 border-b border-agro-100 bg-white/90 backdrop-blur">
      <nav
        aria-label="Navegación principal"
        className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3 sm:px-6 lg:px-8"
      >
        <Link
          href="/"
          className="flex items-center gap-2 text-agro-700 font-display font-bold text-lg"
        >
          <span className="flex h-9 w-9 items-center justify-center rounded-xl2 bg-agro-500 text-white">
            <Leaf size={20} aria-hidden="true" />
          </span>
          AgroScan
        </Link>

        <ul className="hidden md:flex items-center gap-8 text-sm font-medium text-agro-800">
          {navLinks.map((link) => (
            <li key={link.href}>
              <Link
                href={link.href}
                className="hover:text-agro-500 transition-colors"
              >
                {link.label}
              </Link>
            </li>
          ))}
        </ul>

        <div className="hidden md:flex items-center gap-3">
          <Link href="/login" className="btn-secondary !py-2 !px-4 text-sm">
            Iniciar sesión
          </Link>
          <Link href="/registro" className="btn-primary !py-2 !px-4 text-sm">
            Registrarse
          </Link>
        </div>

        {/* Botón de menú móvil: se conecta a un menú desplegable en fases futuras */}
        <button
          type="button"
          className="md:hidden flex h-11 w-11 items-center justify-center rounded-xl2 border border-agro-200 text-agro-700"
          aria-label="Abrir menú de navegación"
        >
          <Menu size={22} aria-hidden="true" />
        </button>
      </nav>
    </header>
  );
}
