import { AlertTriangle, Sparkles } from "lucide-react";
import type { AIAnalysisResult } from "@/types";
import { severityMeta } from "@/lib/utils";

interface AnalysisSummaryCardProps {
  result: AIAnalysisResult;
}

/**
 * Muestra un resumen del resultado de la IA. Se usa tanto en el escáner
 * (vista inmediata) como base para la página de resultado completa de la
 * Fase 7. Sigue el principio de transparencia del punto 17: nunca dice
 * "diagnóstico definitivo", siempre "posible diagnóstico".
 */
export default function AnalysisSummaryCard({ result }: AnalysisSummaryCardProps) {
  const severity = severityMeta(result.diagnosis.severity);
  const confidencePercent = Math.round(result.diagnosis.confidence * 100);

  return (
    <div className="card p-5">
      {result.isDemoResult && (
        <div className="mb-4 flex items-center gap-2 rounded-xl2 bg-earth-100 px-3 py-2 text-xs font-bold uppercase tracking-wide text-earth-700">
          <Sparkles size={14} aria-hidden="true" />
          Resultado de demostración
        </div>
      )}

      <p className="text-sm text-agro-800/60">🌱 Planta identificada</p>
      <p className="font-display text-lg font-bold text-agro-900">{result.plant.name}</p>
      {result.plant.scientificName && (
        <p className="text-sm italic text-agro-800/60">{result.plant.scientificName}</p>
      )}

      <div className="mt-4 border-t border-agro-100 pt-4">
        <p className="text-sm text-agro-800/60">🔎 Posible diagnóstico</p>
        <p className="font-display text-lg font-bold text-agro-900">{result.diagnosis.name}</p>

        <div className="mt-2 flex flex-wrap items-center gap-2">
          <span className={`rounded-full px-3 py-1 text-xs font-bold ${severity.color}`}>
            Severidad: {severity.label}
          </span>
          <span className="rounded-full bg-tech-100 px-3 py-1 text-xs font-bold text-tech-700">
            Confianza: {confidencePercent}%
          </span>
        </div>
      </div>

      {result.symptoms.length > 0 && (
        <div className="mt-4 border-t border-agro-100 pt-4">
          <p className="text-sm font-semibold text-agro-800">👀 Síntomas observados</p>
          <ul className="mt-1 list-disc pl-5 text-sm text-agro-800/80">
            {result.symptoms.map((s, i) => (
              <li key={i}>{s}</li>
            ))}
          </ul>
        </div>
      )}

      {result.warnings.map((warning, i) => (
        <div
          key={i}
          role="alert"
          className="mt-4 flex items-start gap-2 rounded-xl2 border border-earth-400/40 bg-earth-50 px-4 py-3 text-sm text-earth-700"
        >
          <AlertTriangle size={18} className="mt-0.5 shrink-0" aria-hidden="true" />
          {warning}
        </div>
      ))}
    </div>
  );
}
