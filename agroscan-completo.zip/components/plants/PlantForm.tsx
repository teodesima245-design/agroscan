"use client";

import { useFormState } from "react-dom";
import { Input } from "@/components/ui/Input";
import { SubmitButton } from "@/components/ui/SubmitButton";
import type { PlantActionState } from "@/lib/plants/actions";
import type { Plant } from "@/types";

interface PlantFormProps {
  action: (prevState: PlantActionState, formData: FormData) => Promise<PlantActionState>;
  initialValues?: Pick<Plant, "name" | "species" | "notes">;
  onSuccess?: () => void;
  submitLabel: string;
}

const initialState: PlantActionState = { success: false };

export default function PlantForm({ action, initialValues, onSuccess, submitLabel }: PlantFormProps) {
  const [state, formAction] = useFormState(async (prev: PlantActionState, formData: FormData) => {
    const result = await action(prev, formData);
    if (result.success) onSuccess?.();
    return result;
  }, initialState);

  return (
    <form action={formAction} className="flex flex-col gap-4" noValidate>
      {state.message && !state.success && (
        <div role="alert" className="rounded-xl2 border border-red-200 bg-red-50 px-4 py-3 text-sm font-medium text-red-700">
          {state.message}
        </div>
      )}

      <Input
        label="Nombre"
        name="name"
        type="text"
        required
        defaultValue={initialValues?.name}
        placeholder="Ej: Tomatera del patio"
        error={state.fieldErrors?.name?.[0]}
      />

      <Input
        label="Especie (opcional)"
        name="species"
        type="text"
        defaultValue={initialValues?.species ?? ""}
        placeholder="Ej: Solanum lycopersicum"
        error={state.fieldErrors?.species?.[0]}
      />

      <div className="flex flex-col gap-1.5">
        <label htmlFor="notes" className="text-sm font-semibold text-agro-900">
          Notas (opcional)
        </label>
        <textarea
          id="notes"
          name="notes"
          rows={3}
          defaultValue={initialValues?.notes ?? ""}
          placeholder="Cualquier detalle que quieras recordar sobre esta planta"
          className="rounded-xl2 border border-agro-200 bg-white px-4 py-2.5 text-agro-900 focus:outline-none focus:ring-2 focus:ring-tech-500"
        />
        {state.fieldErrors?.notes?.[0] && (
          <p role="alert" className="text-xs font-medium text-red-600">
            {state.fieldErrors.notes[0]}
          </p>
        )}
      </div>

      <SubmitButton loadingText="Guardando...">{submitLabel}</SubmitButton>
    </form>
  );
}
