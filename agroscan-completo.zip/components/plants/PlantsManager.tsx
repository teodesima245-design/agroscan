"use client";

import { useState, useTransition } from "react";
import Link from "next/link";
import { Plus, Pencil, Trash2, Sprout, History, X } from "lucide-react";
import { createPlantAction, updatePlantAction, deletePlantAction } from "@/lib/plants/actions";
import PlantForm from "@/components/plants/PlantForm";
import { formatDate } from "@/lib/utils";
import type { Plant } from "@/types";

interface PlantsManagerProps {
  plants: (Plant & { scanCount: number })[];
}

export default function PlantsManager({ plants }: PlantsManagerProps) {
  const [items, setItems] = useState(plants);
  const [showAddForm, setShowAddForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [pendingDeleteId, setPendingDeleteId] = useState<string | null>(null);
  const [isPending, startTransition] = useTransition();

  const handleDelete = (plantId: string) => {
    setPendingDeleteId(null);
    startTransition(async () => {
      const result = await deletePlantAction(plantId);
      if (result.success) {
        setItems((prev) => prev.filter((p) => p.id !== plantId));
      }
    });
  };

  return (
    <div>
      {!showAddForm ? (
        <button
          type="button"
          onClick={() => setShowAddForm(true)}
          className="btn-primary"
        >
          <Plus size={20} aria-hidden="true" />
          Agregar planta
        </button>
      ) : (
        <div className="card mb-6 p-6">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="font-display text-lg font-bold text-agro-900">Nueva planta</h2>
            <button
              type="button"
              onClick={() => setShowAddForm(false)}
              aria-label="Cerrar formulario"
              className="text-agro-500 hover:text-agro-700"
            >
              <X size={20} aria-hidden="true" />
            </button>
          </div>
          <PlantForm
            action={createPlantAction}
            submitLabel="Guardar planta"
            onSuccess={() => setShowAddForm(false)}
          />
        </div>
      )}

      {items.length === 0 && !showAddForm ? (
        <div className="card mt-6 flex flex-col items-center gap-3 p-10 text-center">
          <Sprout size={32} className="text-agro-300" aria-hidden="true" />
          <p className="font-semibold text-agro-900">Todavía no agregaste ninguna planta</p>
          <p className="text-sm text-agro-800/60">
            Registrá tus plantas para llevar un seguimiento organizado de cada una.
          </p>
        </div>
      ) : (
        <ul className="mt-6 grid gap-4 sm:grid-cols-2">
          {items.map((plant) => (
            <li key={plant.id} className="card p-5">
              {editingId === plant.id ? (
                <div>
                  <div className="mb-3 flex items-center justify-between">
                    <h3 className="font-display font-bold text-agro-900">Editar planta</h3>
                    <button
                      type="button"
                      onClick={() => setEditingId(null)}
                      aria-label="Cancelar edición"
                      className="text-agro-500 hover:text-agro-700"
                    >
                      <X size={18} aria-hidden="true" />
                    </button>
                  </div>
                  <PlantForm
                    action={updatePlantAction.bind(null, plant.id)}
                    initialValues={plant}
                    submitLabel="Guardar cambios"
                    onSuccess={() => {
                      setEditingId(null);
                      setItems((prev) =>
                        prev.map((p) => (p.id === plant.id ? { ...p, ...plant } : p))
                      );
                    }}
                  />
                </div>
              ) : (
                <>
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-3">
                      <span className="flex h-10 w-10 items-center justify-center rounded-xl2 bg-agro-100 text-agro-600">
                        <Sprout size={20} aria-hidden="true" />
                      </span>
                      <div>
                        <p className="font-display font-bold text-agro-900">{plant.name}</p>
                        {plant.species && (
                          <p className="text-xs italic text-agro-800/60">{plant.species}</p>
                        )}
                      </div>
                    </div>

                    <div className="flex gap-1">
                      <button
                        type="button"
                        onClick={() => setEditingId(plant.id)}
                        aria-label={`Editar ${plant.name}`}
                        className="flex h-9 w-9 items-center justify-center rounded-xl2 text-agro-500 hover:bg-agro-50"
                      >
                        <Pencil size={16} aria-hidden="true" />
                      </button>
                      {pendingDeleteId === plant.id ? (
                        <button
                          type="button"
                          onClick={() => handleDelete(plant.id)}
                          disabled={isPending}
                          className="rounded-xl2 bg-red-600 px-2 text-xs font-bold text-white hover:bg-red-700"
                        >
                          Confirmar
                        </button>
                      ) : (
                        <button
                          type="button"
                          onClick={() => setPendingDeleteId(plant.id)}
                          aria-label={`Eliminar ${plant.name}`}
                          className="flex h-9 w-9 items-center justify-center rounded-xl2 text-agro-500 hover:bg-red-50 hover:text-red-600"
                        >
                          <Trash2 size={16} aria-hidden="true" />
                        </button>
                      )}
                    </div>
                  </div>

                  {plant.notes && (
                    <p className="mt-3 text-sm text-agro-800/70 line-clamp-3">{plant.notes}</p>
                  )}

                  <div className="mt-4 flex items-center justify-between border-t border-agro-100 pt-3">
                    <span className="text-xs text-agro-800/50">
                      Agregada el {formatDate(plant.createdAt)}
                    </span>
                    <Link
                      href={`/historial?planta=${plant.id}`}
                      className="flex items-center gap-1 text-xs font-semibold text-tech-600 hover:text-tech-700"
                    >
                      <History size={14} aria-hidden="true" />
                      {plant.scanCount} {plant.scanCount === 1 ? "análisis" : "análisis"}
                    </Link>
                  </div>
                </>
              )}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
