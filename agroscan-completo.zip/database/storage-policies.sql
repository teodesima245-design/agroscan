-- =============================================================================
-- AGROSCAN: GUARDIANES ECOLÓGICOS — ALMACENAMIENTO DE IMÁGENES
-- =============================================================================
-- Cómo ejecutar este archivo:
-- 1. Entrá a tu proyecto en https://app.supabase.com
-- 2. Andá a "SQL Editor" -> "New query"
-- 3. Pegá TODO el contenido de este archivo y hacé clic en "Run"
--    (ejecutar DESPUÉS de schema.sql)
--
-- Esto crea el bucket "plant-images" en Supabase Storage y las políticas
-- de seguridad (RLS) para que cada usuario solo pueda subir, ver y borrar
-- SUS PROPIAS imágenes (punto 20 y 21 del prompt maestro).
-- =============================================================================

-- =============================================================================
-- 1. CREAR EL BUCKET
-- Privado (public = false): las imágenes NO son accesibles por URL directa.
-- Para mostrarlas se generan URLs firmadas de corta duración
-- (ver services/storage/getScanImageUrl en el código de la app).
-- =============================================================================

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values (
  'plant-images',
  'plant-images',
  false,
  10485760, -- 10 MB, coincide con el límite validado en el cliente
  array['image/jpeg', 'image/jpg', 'image/png', 'image/webp']
)
on conflict (id) do update set
  file_size_limit = excluded.file_size_limit,
  allowed_mime_types = excluded.allowed_mime_types;

-- =============================================================================
-- 2. CONVENCIÓN DE RUTAS
-- Cada imagen se guarda como: {user_id}/{nombre_de_archivo_unico}.ext
-- El primer segmento de la ruta (la "carpeta") es siempre el UUID del
-- usuario dueño de la imagen. Las políticas de abajo se apoyan en esa
-- convención para restringir el acceso.
-- =============================================================================

-- =============================================================================
-- 3. POLÍTICAS DE SEGURIDAD (RLS sobre storage.objects)
-- =============================================================================

drop policy if exists "plant_images_insert_own" on storage.objects;
create policy "plant_images_insert_own"
  on storage.objects for insert
  with check (
    bucket_id = 'plant-images'
    and auth.uid()::text = (storage.foldername(name))[1]
  );

drop policy if exists "plant_images_select_own" on storage.objects;
create policy "plant_images_select_own"
  on storage.objects for select
  using (
    bucket_id = 'plant-images'
    and auth.uid()::text = (storage.foldername(name))[1]
  );

drop policy if exists "plant_images_delete_own" on storage.objects;
create policy "plant_images_delete_own"
  on storage.objects for delete
  using (
    bucket_id = 'plant-images'
    and auth.uid()::text = (storage.foldername(name))[1]
  );

-- No se permite "update" de imágenes: si el usuario quiere reemplazar una
-- foto, se sube un archivo nuevo y se borra el anterior. Esto evita
-- inconsistencias con los análisis ya guardados que referencian la imagen.

-- =============================================================================
-- FIN — Próximo paso (Fase 6): conectar analyzePlantImage() con un
-- proveedor real de IA que reciba la URL firmada de la imagen subida.
-- =============================================================================
