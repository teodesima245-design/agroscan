-- =============================================================================
-- AGROSCAN: GUARDIANES ECOLÓGICOS — ESQUEMA DE BASE DE DATOS
-- =============================================================================
-- Cómo ejecutar este archivo:
-- 1. Entrá a tu proyecto en https://app.supabase.com
-- 2. Andá a "SQL Editor" -> "New query"
-- 3. Pegá TODO el contenido de este archivo y hacé clic en "Run"
--
-- Este script es idempotente donde es razonable (usa IF NOT EXISTS), pero
-- está pensado para ejecutarse UNA sola vez sobre un proyecto nuevo.
-- =============================================================================

-- Extensión necesaria para generar UUIDs
create extension if not exists "uuid-ossp";

-- =============================================================================
-- 1. TABLA: users
-- Perfil extendido del usuario. La tabla de autenticación real
-- (auth.users) la administra Supabase Auth; esta tabla la complementa
-- con los datos propios de AgroScan (país, tipo de usuario, etc.)
-- =============================================================================

create table if not exists public.users (
  id uuid primary key references auth.users(id) on delete cascade,
  name text not null check (char_length(name) between 2 and 80),
  email text not null unique,
  country text not null,
  user_type text not null check (
    user_type in ('estudiante', 'jardinero', 'agricultor', 'huerta_familiar', 'otro')
  ),
  created_at timestamptz not null default now()
);

comment on table public.users is 'Perfil extendido de cada usuario de AgroScan.';

-- =============================================================================
-- 2. TABLA: plants ("Mis plantas")
-- =============================================================================

create table if not exists public.plants (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references public.users(id) on delete cascade,
  name text not null check (char_length(name) between 1 and 80),
  species text,
  notes text check (char_length(notes) <= 2000),
  created_at timestamptz not null default now()
);

comment on table public.plants is 'Plantas registradas por cada usuario para llevar seguimiento.';

create index if not exists idx_plants_user_id on public.plants(user_id);
create index if not exists idx_plants_created_at on public.plants(created_at desc);

-- =============================================================================
-- 3. TABLA: scans ("Mi historial")
-- Guarda cada análisis realizado, con el resultado estructurado de la IA
-- (ver el contrato AIAnalysisResult en /types/index.ts).
-- =============================================================================

create table if not exists public.scans (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references public.users(id) on delete cascade,
  plant_id uuid references public.plants(id) on delete set null,

  -- Referencia a la imagen en Supabase Storage (nunca se guarda el binario acá)
  image_url text not null,

  -- Identificación de la planta devuelta por la IA
  plant_name text not null,
  scientific_name text not null default '',

  -- Diagnóstico
  diagnosis text not null,
  category text not null check (
    category in (
      'enfermedad',
      'plaga',
      'deficiencia_nutricional',
      'estres_ambiental',
      'daño_fisico',
      'planta_saludable',
      'desconocido'
    )
  ),
  confidence numeric(4, 3) not null check (confidence >= 0 and confidence <= 1),
  severity text not null check (severity in ('baja', 'media', 'alta', 'desconocida')),

  -- Listas de texto (síntomas, causas, recomendaciones, prevención)
  symptoms text[] not null default '{}',
  causes text[] not null default '{}',
  recommendations text[] not null default '{}',
  prevention text[] not null default '{}',

  -- true si el resultado vino del Demo Mode y no de un análisis real de IA
  is_demo_result boolean not null default false,

  created_at timestamptz not null default now()
);

comment on table public.scans is 'Historial de análisis de plantas realizados por cada usuario.';

create index if not exists idx_scans_user_id on public.scans(user_id);
create index if not exists idx_scans_plant_id on public.scans(plant_id);
create index if not exists idx_scans_created_at on public.scans(created_at desc);
create index if not exists idx_scans_category on public.scans(category);

-- =============================================================================
-- 4. ROW LEVEL SECURITY (RLS)
-- Cada usuario solo puede ver y modificar sus propios datos.
-- =============================================================================

alter table public.users enable row level security;
alter table public.plants enable row level security;
alter table public.scans enable row level security;

-- --- Políticas para "users" ---

drop policy if exists "users_select_own" on public.users;
create policy "users_select_own"
  on public.users for select
  using (auth.uid() = id);

drop policy if exists "users_update_own" on public.users;
create policy "users_update_own"
  on public.users for update
  using (auth.uid() = id)
  with check (auth.uid() = id);

-- No se permite insertar manualmente: el perfil se crea automáticamente
-- mediante el trigger handle_new_user() al registrarse (ver más abajo).
-- No se permite eliminar directamente: se hace en cascada al eliminar
-- el usuario de auth.users (por ejemplo, mediante una función administrativa).

-- --- Políticas para "plants" ---

drop policy if exists "plants_select_own" on public.plants;
create policy "plants_select_own"
  on public.plants for select
  using (auth.uid() = user_id);

drop policy if exists "plants_insert_own" on public.plants;
create policy "plants_insert_own"
  on public.plants for insert
  with check (auth.uid() = user_id);

drop policy if exists "plants_update_own" on public.plants;
create policy "plants_update_own"
  on public.plants for update
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

drop policy if exists "plants_delete_own" on public.plants;
create policy "plants_delete_own"
  on public.plants for delete
  using (auth.uid() = user_id);

-- --- Políticas para "scans" ---

drop policy if exists "scans_select_own" on public.scans;
create policy "scans_select_own"
  on public.scans for select
  using (auth.uid() = user_id);

drop policy if exists "scans_insert_own" on public.scans;
create policy "scans_insert_own"
  on public.scans for insert
  with check (auth.uid() = user_id);

drop policy if exists "scans_update_own" on public.scans;
create policy "scans_update_own"
  on public.scans for update
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

drop policy if exists "scans_delete_own" on public.scans;
create policy "scans_delete_own"
  on public.scans for delete
  using (auth.uid() = user_id);

-- =============================================================================
-- 5. TRIGGER: crear automáticamente el perfil en "users" al registrarse
-- Toma los metadatos enviados desde signUpAction() en /lib/auth/actions.ts
-- (name, country, user_type) y crea la fila correspondiente en public.users.
-- =============================================================================

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.users (id, name, email, country, user_type)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'name', split_part(new.email, '@', 1)),
    new.email,
    coalesce(new.raw_user_meta_data->>'country', 'Otro'),
    coalesce(new.raw_user_meta_data->>'user_type', 'otro')
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- =============================================================================
-- 6. FUNCIÓN AUXILIAR: estadísticas rápidas del dashboard
-- Usada en la Fase 8 para evitar hacer varias consultas separadas.
-- =============================================================================

create or replace function public.get_user_stats(p_user_id uuid)
returns table (
  total_scans bigint,
  total_plants bigint,
  problems_detected bigint,
  last_scan_at timestamptz
)
language sql
security definer
set search_path = public
as $$
  select
    (select count(*) from public.scans where user_id = p_user_id) as total_scans,
    (select count(*) from public.plants where user_id = p_user_id) as total_plants,
    (select count(*) from public.scans
       where user_id = p_user_id and category != 'planta_saludable') as problems_detected,
    (select max(created_at) from public.scans where user_id = p_user_id) as last_scan_at;
$$;

-- =============================================================================
-- FIN DEL ESQUEMA
-- Próximo paso (Fase 5): crear el bucket de Storage "plant-images" y sus
-- políticas de acceso — ver /database/storage-policies.sql
-- =============================================================================
