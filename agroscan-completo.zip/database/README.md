# Base de datos de AgroScan

Este esquema está pensado para **Supabase (PostgreSQL)**.

## Cómo aplicarlo

1. Creá tu proyecto en [supabase.com](https://supabase.com) (si todavía no lo hiciste).
2. Andá a **SQL Editor → New query**.
3. Pegá todo el contenido de `schema.sql` y ejecutalo.
4. Verificá en **Table Editor** que aparecieron las tablas `users`, `plants` y `scans`.

## Diagrama de relaciones

```
auth.users (administrada por Supabase Auth)
      │
      │ 1:1 (trigger automático al registrarse)
      ▼
public.users ──────┐
      │             │
      │ 1:N          │ 1:N
      ▼             ▼
public.plants   public.scans
      │             ▲
      └─────1:N──────┘
      (un scan puede asociarse opcionalmente a una planta)
```

## Decisiones de diseño

- **`handle_new_user()` (trigger):** cuando alguien se registra mediante
  `signUpAction()`, Supabase Auth crea la fila en `auth.users`. Este trigger
  se dispara automáticamente y copia `name`, `country` y `user_type` (que
  viajan como metadata desde el formulario de registro) a `public.users`.
  Así nunca hace falta un segundo paso manual para completar el perfil.

- **Row Level Security (RLS) activado en las 3 tablas:** un usuario
  autenticado solo puede leer, insertar, actualizar o eliminar **sus
  propias** filas (comparando `auth.uid()` contra `user_id` o `id`). Esto
  es lo que garantiza, a nivel de base de datos, que un usuario nunca pueda
  ver los análisis de otra persona — incluso si hubiera un error en el
  código del frontend.

- **`plant_id` en `scans` es opcional (`on delete set null`):** un análisis
  puede hacerse sin asociarlo a ninguna planta guardada, y si el usuario
  borra una planta, sus escaneos anteriores no se pierden — solo pierden la
  referencia.

- **`confidence` como `numeric(4,3)`:** guarda valores entre 0.000 y 1.000,
  suficiente precisión para mostrar el nivel de confianza sin desperdiciar
  espacio.

- **`get_user_stats()`:** función auxiliar para traer todas las
  estadísticas del dashboard en una sola consulta (se conecta en la Fase 8).

## Próximos pasos relacionados

- **Fase 5:** se agregará `storage-policies.sql` en esta misma carpeta,
  con la creación del bucket `plant-images` y sus políticas de acceso.
- **Regenerar tipos de TypeScript** (opcional, recomendado):
  ```bash
  npx supabase gen types typescript --project-id TU_PROJECT_ID > lib/supabase/database.types.ts
  ```
