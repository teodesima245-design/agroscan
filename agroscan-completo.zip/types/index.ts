/**
 * Tipos centrales del dominio de AgroScan: Guardianes Ecológicos.
 * Estos tipos reflejan la estructura de la base de datos (ver /database/schema.sql)
 * y el contrato de la capa de inteligencia artificial (ver /services/ai).
 */

// ---------------------------------------------------------------------------
// USUARIOS
// ---------------------------------------------------------------------------

export type UserType =
  | "estudiante"
  | "jardinero"
  | "agricultor"
  | "huerta_familiar"
  | "otro";

export interface AppUser {
  id: string;
  name: string;
  email: string;
  country: string;
  userType: UserType;
  createdAt: string;
}

// ---------------------------------------------------------------------------
// PLANTAS ("Mis plantas")
// ---------------------------------------------------------------------------

export interface Plant {
  id: string;
  userId: string;
  name: string;
  species?: string | null;
  notes?: string | null;
  createdAt: string;
}

// ---------------------------------------------------------------------------
// CATEGORÍAS Y SEVERIDAD DE DIAGNÓSTICO
// ---------------------------------------------------------------------------

export type DiagnosisCategory =
  | "enfermedad"
  | "plaga"
  | "deficiencia_nutricional"
  | "estres_ambiental"
  | "daño_fisico"
  | "planta_saludable"
  | "desconocido";

export type SeverityLevel = "baja" | "media" | "alta" | "desconocida";

// ---------------------------------------------------------------------------
// RESULTADO ESTRUCTURADO DE LA IA
// Este es el contrato que debe cumplir CUALQUIER proveedor de IA que se
// conecte a través de analyzePlantImage(). Ver /services/ai/index.ts
// ---------------------------------------------------------------------------

export interface PlantIdentification {
  name: string;
  scientificName: string;
  confidence: number; // 0 a 1
}

export interface Diagnosis {
  category: DiagnosisCategory;
  name: string;
  confidence: number; // 0 a 1
  severity: SeverityLevel;
}

export interface AIAnalysisResult {
  plant: PlantIdentification;
  diagnosis: Diagnosis;
  symptoms: string[];
  possibleCauses: string[];
  recommendations: string[];
  prevention: string[];
  warnings: string[];
  /** true cuando el resultado proviene del Demo Mode y no de un análisis real de IA */
  isDemoResult: boolean;
}

// ---------------------------------------------------------------------------
// ESCANEOS ("Mi historial")
// ---------------------------------------------------------------------------

export interface Scan {
  id: string;
  userId: string;
  plantId?: string | null;
  imageUrl: string;
  plantName: string;
  scientificName: string;
  diagnosisCategory: DiagnosisCategory;
  diagnosisName: string;
  confidence: number;
  severity: SeverityLevel;
  symptoms: string[];
  causes: string[];
  recommendations: string[];
  prevention: string[];
  isDemoResult: boolean;
  createdAt: string;
}

// ---------------------------------------------------------------------------
// VALIDACIÓN DE IMÁGENES
// ---------------------------------------------------------------------------

export interface ImageValidationResult {
  valid: boolean;
  errorMessage?: string;
}

// ---------------------------------------------------------------------------
// ESTADOS DE CARGA DEL ESCÁNER
// ---------------------------------------------------------------------------

export type ScanStage =
  | "idle"
  | "validando"
  | "subiendo"
  | "analizando"
  | "preparando_resultado"
  | "completo"
  | "error";
