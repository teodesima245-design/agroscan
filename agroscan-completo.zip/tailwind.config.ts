import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        // Paleta AgroScan: verdes de agricultura/ecología + azul tecnológico de IA
        agro: {
          50: "#f1f9ee",
          100: "#e0f2da",
          200: "#c2e5b6",
          300: "#98d187",
          400: "#6cb85c",
          500: "#4a9c3d", // verde principal
          600: "#387d2f",
          700: "#2d6327",
          800: "#264f22",
          900: "#20421f",
        },
        tech: {
          50: "#eef6ff",
          100: "#d9ebff",
          400: "#4d9bff",
          500: "#2478f0", // azul IA/tecnología
          600: "#155fce",
          700: "#134da5",
        },
        earth: {
          50: "#faf7f2",
          100: "#f0e6d6",
          400: "#c9a36b",
          500: "#a97e45", // tierra/agricultura
          700: "#6e5230",
        },
      },
      fontFamily: {
        sans: ["var(--font-sans)", "system-ui", "sans-serif"],
        display: ["var(--font-display)", "system-ui", "sans-serif"],
      },
      borderRadius: {
        xl2: "1.25rem",
      },
      animation: {
        "fade-up": "fadeUp 0.6s ease-out both",
        "scan-line": "scanLine 2s ease-in-out infinite",
      },
      keyframes: {
        fadeUp: {
          "0%": { opacity: "0", transform: "translateY(12px)" },
          "100%": { opacity: "1", transform: "translateY(0)" },
        },
        scanLine: {
          "0%, 100%": { transform: "translateY(0)" },
          "50%": { transform: "translateY(100%)" },
        },
      },
    },
  },
  plugins: [],
};

export default config;
