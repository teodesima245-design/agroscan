import { createClient } from "@/lib/supabase/client";
import { STORAGE_BUCKET } from "@/lib/constants";

export interface UploadResult {
  success: boolean;
  /** Ruta interna del archivo dentro del bucket (se guarda en scans.image_url). */
  path?: string;
  errorMessage?: string;
}

/**
 * Sube una imagen de planta al bucket privado "plant-images", dentro de
 * la carpeta del usuario autenticado (requisito de las políticas RLS de
 * Storage: ver /database/storage-policies.sql).
 *
 * Devuelve la RUTA interna del archivo, no una URL pública, porque el
 * bucket es privado (punto 20 del prompt: "las imágenes deben estar
 * protegidas"). Para mostrar la imagen se usa getScanImageUrl().
 */
export async function uploadPlantImage(
  file: File,
  userId: string
): Promise<UploadResult> {
  const supabase = createClient();

  const extension = file.name.split(".").pop()?.toLowerCase() || "jpg";
  const uniqueName = `${crypto.randomUUID()}.${extension}`;
  const path = `${userId}/${uniqueName}`;

  const { error } = await supabase.storage.from(STORAGE_BUCKET).upload(path, file, {
    cacheControl: "3600",
    upsert: false,
    contentType: file.type,
  });

  if (error) {
    return {
      success: false,
      errorMessage:
        "No pudimos subir la imagen. Revisá tu conexión a internet e intentá nuevamente.",
    };
  }

  return { success: true, path };
}

/**
 * Genera una URL firmada de corta duración para mostrar una imagen privada
 * (por ejemplo, en el historial o en la pantalla de resultado).
 * Por defecto expira en 1 hora.
 */
export async function getScanImageUrl(
  path: string,
  expiresInSeconds = 3600
): Promise<string | null> {
  const supabase = createClient();
  const { data, error } = await supabase.storage
    .from(STORAGE_BUCKET)
    .createSignedUrl(path, expiresInSeconds);

  if (error || !data) return null;
  return data.signedUrl;
}

/**
 * Elimina una imagen del bucket. Se usa cuando el usuario borra un
 * análisis de su historial (Fase 8) o cuando falla un paso posterior a
 * la subida y hay que revertir (evita imágenes huérfanas).
 */
export async function deletePlantImage(path: string): Promise<boolean> {
  const supabase = createClient();
  const { error } = await supabase.storage.from(STORAGE_BUCKET).remove([path]);
  return !error;
}
