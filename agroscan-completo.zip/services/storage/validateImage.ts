import type { ImageValidationResult } from "@/types";
import {
  ACCEPTED_IMAGE_FORMATS,
  MAX_IMAGE_SIZE_BYTES,
  MAX_IMAGE_SIZE_MB,
  MIN_IMAGE_WIDTH,
  MIN_IMAGE_HEIGHT,
} from "@/lib/constants";

const IMAGE_UNCLEAR_MESSAGE =
  "La imagen no es suficientemente clara. Intentá tomar otra fotografía con buena iluminación y enfocando la parte afectada de la planta.";

/**
 * Valida una imagen antes de subirla o analizarla (punto 12 del prompt
 * maestro). Comprueba, en este orden:
 *   1. Formato
 *   2. Tamaño
 *   3. Que el archivo pueda abrirse correctamente (no esté corrupto)
 *   4. Resolución mínima
 *
 * Esta validación corre en el navegador para dar feedback inmediato.
 * La subida a Storage además queda protegida por los límites configurados
 * en el bucket (ver /database/storage-policies.sql), como segunda barrera.
 */
export async function validatePlantImage(file: File): Promise<ImageValidationResult> {
  if (!ACCEPTED_IMAGE_FORMATS.includes(file.type as (typeof ACCEPTED_IMAGE_FORMATS)[number])) {
    return { valid: false, errorMessage: IMAGE_UNCLEAR_MESSAGE };
  }

  if (file.size > MAX_IMAGE_SIZE_BYTES) {
    return {
      valid: false,
      errorMessage: `La imagen es demasiado grande. El tamaño máximo permitido es ${MAX_IMAGE_SIZE_MB}MB.`,
    };
  }

  if (file.size === 0) {
    return { valid: false, errorMessage: IMAGE_UNCLEAR_MESSAGE };
  }

  // Verificar que el archivo se pueda abrir correctamente y medir su resolución.
  const dimensions = await readImageDimensions(file);
  if (!dimensions) {
    return {
      valid: false,
      errorMessage:
        "No pudimos abrir esta imagen. Puede estar dañada. Intentá con otra fotografía.",
    };
  }

  if (dimensions.width < MIN_IMAGE_WIDTH || dimensions.height < MIN_IMAGE_HEIGHT) {
    return {
      valid: false,
      errorMessage: IMAGE_UNCLEAR_MESSAGE,
    };
  }

  return { valid: true };
}

function readImageDimensions(
  file: File
): Promise<{ width: number; height: number } | null> {
  return new Promise((resolve) => {
    const url = URL.createObjectURL(file);
    const img = new Image();

    img.onload = () => {
      resolve({ width: img.naturalWidth, height: img.naturalHeight });
      URL.revokeObjectURL(url);
    };

    img.onerror = () => {
      resolve(null);
      URL.revokeObjectURL(url);
    };

    img.src = url;
  });
}
