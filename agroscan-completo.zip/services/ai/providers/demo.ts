import type { AIAnalysisResult } from "@/types";
import { pickDemoCase } from "@/lib/demo/cases";

/**
 * Proveedor "demo": no se conecta a ninguna API externa. Devuelve uno de
 * los casos predefinidos en /lib/demo/cases.ts de forma determinística
 * según la imagen recibida (para que la misma imagen siempre dé el mismo
 * resultado dentro de una sesión de prueba).
 *
 * Es el proveedor por defecto (AI_API_PROVIDER=demo en .env.example),
 * porque AgroScan es 100% gratuito y este proveedor permite usar toda la
 * aplicación sin depender de ninguna clave de pago (punto 4 del prompt).
 *
 * IMPORTANTE: el resultado siempre trae isDemoResult: true. La interfaz
 * debe mostrar esto de forma visible (ver /components/results), nunca
 * como si fuera un análisis real de IA.
 */
export async function analyzeWithDemoProvider(imageUrl: string): Promise<AIAnalysisResult> {
  // Simula un breve tiempo de procesamiento para que los estados de carga
  // ("Analizando tu planta...") se vean de forma realista.
  await new Promise((resolve) => setTimeout(resolve, 800));

  const demoCase = pickDemoCase(imageUrl);
  return demoCase.result;
}
