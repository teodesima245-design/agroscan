import type { AIAnalysisResult } from "@/types";

/**
 * Proveedor "huggingface": usa la API de Inferencia de Hugging Face para
 * clasificar imágenes con un modelo de visión entrenado en enfermedades
 * de plantas (por ejemplo, modelos públicos entrenados sobre el dataset
 * PlantVillage).
 *
 * CREDENCIAL NECESARIA:
 *   AI_API_KEY = tu token de acceso de Hugging Face
 *   Se obtiene gratis en: https://huggingface.co/settings/tokens
 *   Colocala en tu archivo ".env.local" (nunca en el código ni en el frontend).
 *
 * MODELO SUGERIDO (gratuito, de código abierto):
 *   Buscá en https://huggingface.co/models?pipeline_tag=image-classification&search=plant
 *   un modelo de clasificación de enfermedades de plantas y reemplazá
 *   MODEL_ENDPOINT por su URL de inferencia.
 *
 * LIMITACIÓN: la API gratuita de Hugging Face Inference tiene límites de
 * uso mensual y el modelo puede "dormirse" tras un tiempo sin uso (la
 * primera consulta puede tardar más mientras se carga). Esto se explica
 * en el README, no se implementa ningún sistema de pago para evitarlo
 * (punto 4 del prompt maestro).
 *
 * Este archivo devuelve una estructura ya adaptada al contrato
 * AIAnalysisResult, pero la clasificación cruda de un modelo de imagen
 * normalmente solo da la ETIQUETA de la enfermedad, no recomendaciones
 * ni causas. Por eso, este proveedor combina el resultado del modelo con
 * una pequeña base de conocimiento local (ver mapLabelToKnowledge) para
 * completar el resto de los campos.
 */

const MODEL_ENDPOINT =
  "https://api-inference.huggingface.co/models/linkanjarad/mobilenet_v2_1.0_224-plant-disease-identification";

export async function analyzeWithHuggingFace(imageUrl: string): Promise<AIAnalysisResult> {
  const apiKey = process.env.AI_API_KEY;

  if (!apiKey) {
    throw new Error(
      "Falta configurar AI_API_KEY en las variables de entorno para usar el proveedor Hugging Face. " +
        "Obtené un token gratuito en https://huggingface.co/settings/tokens y colocalo en .env.local. " +
        "Mientras tanto, podés usar AI_API_PROVIDER=demo."
    );
  }

  const imageResponse = await fetch(imageUrl);
  if (!imageResponse.ok) {
    throw new Error("No se pudo descargar la imagen para enviarla al modelo de IA.");
  }
  const imageBlob = await imageResponse.blob();

  const inferenceResponse = await fetch(MODEL_ENDPOINT, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${apiKey}`,
      "Content-Type": imageBlob.type || "application/octet-stream",
    },
    body: imageBlob,
  });

  if (!inferenceResponse.ok) {
    if (inferenceResponse.status === 503) {
      throw new Error(
        "El modelo de IA se está cargando (esto puede pasar tras un período sin uso). Intentá nuevamente en unos 20 segundos."
      );
    }
    throw new Error("El servicio de inteligencia artificial no respondió correctamente.");
  }

  // La API de clasificación de Hugging Face devuelve algo como:
  // [{ label: "Tomato___Early_blight", score: 0.87 }, ...]
  const predictions: Array<{ label: string; score: number }> = await inferenceResponse.json();

  if (!Array.isArray(predictions) || predictions.length === 0) {
    throw new Error("El modelo de IA no devolvió un resultado válido.");
  }

  const top = predictions[0];
  return mapLabelToKnowledge(top.label, top.score);
}

/**
 * Traduce la etiqueta cruda del modelo (en inglés, formato dataset) a la
 * estructura completa en español que espera la interfaz de AgroScan.
 * Esta base de conocimiento se puede ampliar fácilmente agregando más
 * entradas a medida que se detecten nuevas etiquetas (ver Fase 42:
 * "Futuras mejoras" del prompt maestro: "Más enfermedades", "Más plagas").
 */
function mapLabelToKnowledge(rawLabel: string, confidence: number): AIAnalysisResult {
  const normalized = rawLabel.toLowerCase();
  const isHealthy = normalized.includes("healthy");

  const [plantPart] = rawLabel.split("___");
  const plantName = plantPart?.replace(/_/g, " ") || "Planta no identificada";

  if (isHealthy) {
    return {
      plant: { name: plantName, scientificName: "", confidence },
      diagnosis: {
        category: "planta_saludable",
        name: "Sin problemas detectados",
        confidence,
        severity: "desconocida",
      },
      symptoms: [],
      possibleCauses: [],
      recommendations: ["Continuar con el cuidado habitual de la planta."],
      prevention: ["Seguir monitoreando la planta periódicamente."],
      warnings: [],
      isDemoResult: false,
    };
  }

  const diagnosisName = rawLabel.split("___")[1]?.replace(/_/g, " ") || "Problema no especificado";

  return {
    plant: { name: plantName, scientificName: "", confidence },
    diagnosis: {
      category: "enfermedad",
      name: diagnosisName,
      confidence,
      severity: confidence > 0.75 ? "media" : "baja",
    },
    symptoms: ["Síntomas detectados automáticamente por el modelo de clasificación."],
    possibleCauses: [
      "Causa determinada por un modelo de inteligencia artificial. Confirmá con un profesional para mayor precisión.",
    ],
    recommendations: [
      "Consultá con un profesional agrícola para confirmar el diagnóstico y definir el tratamiento adecuado.",
    ],
    prevention: [
      "Mantené buenas prácticas de riego, ventilación e higiene de herramientas.",
    ],
    warnings: [
      "Este resultado proviene de un modelo de clasificación general y puede no ser preciso para todas las especies.",
    ],
    isDemoResult: false,
  };
}
