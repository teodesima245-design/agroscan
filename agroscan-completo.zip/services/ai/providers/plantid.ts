import type { AIAnalysisResult, DiagnosisCategory, SeverityLevel } from "@/types";

/**
 * Proveedor "plantid": usa la API de Plant.id (https://plant.id), una
 * API comercial especializada en identificación de plantas y evaluación
 * de salud (detecta enfermedades, plagas y deficiencias reales, con una
 * base de conocimiento mucho más amplia que un modelo genérico).
 *
 * CREDENCIAL NECESARIA:
 *   AI_API_KEY = tu clave de API de Plant.id
 *   Se obtiene registrándose en: https://web.plant.id/
 *   Ofrecen un plan gratuito limitado, suficiente para pruebas y para
 *   una feria de ciencias. Colocá la clave en ".env.local".
 *
 * LIMITACIÓN: el plan gratuito tiene un número reducido de consultas por
 * mes. Si se agotan, la aplicación NO debe cobrar ni bloquear funciones:
 * simplemente cambiá AI_API_PROVIDER a "demo" en las variables de entorno
 * hasta el siguiente ciclo (punto 4 del prompt maestro).
 */

const PLANT_ID_ENDPOINT = "https://plant.id/api/v3/health_assessment";

interface PlantIdDisease {
  name: string;
  probability: number;
  description?: string;
  treatment?: {
    biological?: string[];
    prevention?: string[];
  };
}

interface PlantIdResponse {
  result: {
    is_healthy: { binary: boolean; probability: number };
    disease: { suggestions: PlantIdDisease[] };
    is_plant: { binary: boolean; probability: number };
  };
}

export async function analyzeWithPlantId(imageUrl: string): Promise<AIAnalysisResult> {
  const apiKey = process.env.AI_API_KEY;

  if (!apiKey) {
    throw new Error(
      "Falta configurar AI_API_KEY en las variables de entorno para usar el proveedor Plant.id. " +
        "Registrate gratis en https://web.plant.id/ y colocá tu clave en .env.local. " +
        "Mientras tanto, podés usar AI_API_PROVIDER=demo."
    );
  }

  const imageResponse = await fetch(imageUrl);
  if (!imageResponse.ok) {
    throw new Error("No se pudo descargar la imagen para enviarla al modelo de IA.");
  }
  const imageBuffer = await imageResponse.arrayBuffer();
  const base64Image = Buffer.from(imageBuffer).toString("base64");

  const response = await fetch(PLANT_ID_ENDPOINT, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Api-Key": apiKey,
    },
    body: JSON.stringify({
      images: [`data:image/jpeg;base64,${base64Image}`],
      similar_images: false,
    }),
  });

  if (!response.ok) {
    if (response.status === 429) {
      throw new Error(
        "Se alcanzó el límite mensual de análisis gratuitos de Plant.id. Probá nuevamente el próximo mes o cambiá a AI_API_PROVIDER=demo."
      );
    }
    throw new Error("El servicio de inteligencia artificial no respondió correctamente.");
  }

  const data: PlantIdResponse = await response.json();
  return mapPlantIdResponse(data);
}

function mapPlantIdResponse(data: PlantIdResponse): AIAnalysisResult {
  const { is_healthy, disease } = data.result;

  if (is_healthy.binary || disease.suggestions.length === 0) {
    return {
      plant: { name: "Planta identificada", scientificName: "", confidence: is_healthy.probability },
      diagnosis: {
        category: "planta_saludable",
        name: "Sin problemas detectados",
        confidence: is_healthy.probability,
        severity: "desconocida",
      },
      symptoms: [],
      possibleCauses: [],
      recommendations: ["Continuar con el cuidado habitual de la planta."],
      prevention: ["Seguir monitoreando la planta periódicamente."],
      warnings: [],
      isDemoResult: false,
    };
  }

  const topDisease = disease.suggestions[0];
  const category: DiagnosisCategory = "enfermedad";
  const severity: SeverityLevel =
    topDisease.probability > 0.75 ? "alta" : topDisease.probability > 0.5 ? "media" : "baja";

  return {
    plant: { name: "Planta identificada", scientificName: "", confidence: 1 - is_healthy.probability },
    diagnosis: {
      category,
      name: topDisease.name,
      confidence: topDisease.probability,
      severity,
    },
    symptoms: topDisease.description ? [topDisease.description] : [],
    possibleCauses: [],
    recommendations: topDisease.treatment?.biological ?? [
      "Consultá con un profesional agrícola para confirmar el diagnóstico.",
    ],
    prevention: topDisease.treatment?.prevention ?? [],
    warnings: [],
    isDemoResult: false,
  };
}
