import type { AIAnalysisResult } from "@/types";
import { aiAnalysisResultSchema, LOW_CONFIDENCE_THRESHOLD } from "@/lib/ai/schema";
import { analyzeWithDemoProvider } from "./providers/demo";
import { analyzeWithHuggingFace } from "./providers/huggingface";
import { analyzeWithPlantId } from "./providers/plantid";

export type AIProvider = "demo" | "huggingface" | "plantid" | "custom";

export class AIAnalysisError extends Error {}

/**
 * Punto único de entrada al análisis de IA (punto 13 del prompt maestro).
 * El resto de la aplicación SIEMPRE llama a esta función, nunca a un
 * proveedor específico directamente. Así, cambiar de proveedor es tan
 * simple como cambiar la variable de entorno AI_API_PROVIDER — no hace
 * falta tocar el resto del código (escáner, resultados, historial, etc.)
 *
 * @param imageUrl URL firmada de la imagen ya subida a Supabase Storage.
 * @returns Un AIAnalysisResult validado y listo para guardar/mostrar.
 * @throws AIAnalysisError con un mensaje ya apto para mostrar al usuario.
 */
export async function analyzePlantImage(imageUrl: string): Promise<AIAnalysisResult> {
  const provider = (process.env.AI_API_PROVIDER || "demo") as AIProvider;

  let rawResult: AIAnalysisResult;

  try {
    switch (provider) {
      case "demo":
        rawResult = await analyzeWithDemoProvider(imageUrl);
        break;
      case "huggingface":
        rawResult = await analyzeWithHuggingFace(imageUrl);
        break;
      case "plantid":
        rawResult = await analyzeWithPlantId(imageUrl);
        break;
      default:
        // "custom": punto de extensión para conectar tu propio modelo
        // (por ejemplo, un modelo TensorFlow Lite propio servido por una
        // API propia). Mientras no esté implementado, se usa el Demo Mode
        // para que la aplicación nunca quede inutilizable.
        rawResult = await analyzeWithDemoProvider(imageUrl);
    }
  } catch (err) {
    // Nunca dejamos pasar el error técnico crudo (punto 32). Preferimos
    // "no estamos seguros" antes que inventar una respuesta (punto 43).
    const technicalMessage = err instanceof Error ? err.message : "Error desconocido de IA.";
    throw new AIAnalysisError(technicalMessage);
  }

  // Validación estructural obligatoria antes de continuar (punto 14).
  const validation = aiAnalysisResultSchema.safeParse(rawResult);
  if (!validation.success) {
    throw new AIAnalysisError(
      "El análisis no pudo completarse porque la respuesta de la inteligencia artificial no tuvo el formato esperado."
    );
  }

  const result = validation.data;

  // Transparencia sobre baja confianza (punto 17): se agrega una
  // advertencia visible en lugar de presentar el resultado como si fuera
  // definitivo.
  if (
    result.diagnosis.confidence < LOW_CONFIDENCE_THRESHOLD &&
    result.diagnosis.category !== "planta_saludable"
  ) {
    result.warnings = [
      ...result.warnings,
      "El análisis no es suficientemente confiable. Intentá realizar otra fotografía o consultá con un profesional especializado.",
    ];
  }

  return result;
}
