/**
 * Constantes compartidas relacionadas con la carga de imágenes.
 * Mantenerlas en un solo lugar evita que el límite de tamaño, por ejemplo,
 * quede desincronizado entre el validador del cliente y el bucket de
 * Supabase Storage (ver /database/storage-policies.sql, que usa el mismo
 * valor en bytes).
 */

export const STORAGE_BUCKET = "plant-images";

export const ACCEPTED_IMAGE_FORMATS = [
  "image/jpeg",
  "image/jpg",
  "image/png",
  "image/webp",
] as const;

export const MAX_IMAGE_SIZE_MB = 10;
export const MAX_IMAGE_SIZE_BYTES = MAX_IMAGE_SIZE_MB * 1024 * 1024;

/** Resolución mínima para que la IA tenga suficiente detalle visual (punto 12). */
export const MIN_IMAGE_WIDTH = 200;
export const MIN_IMAGE_HEIGHT = 200;
