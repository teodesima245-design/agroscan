/**
 * Tipos de la base de datos de Supabase.
 *
 * NOTA: este archivo es un placeholder manual que refleja el esquema
 * definido en /database/schema.sql (Fase 4). Cuando tengas tu proyecto
 * de Supabase creado, podés regenerarlo automáticamente con:
 *
 *   npx supabase gen types typescript --project-id TU_PROJECT_ID > lib/supabase/database.types.ts
 *
 * Mientras tanto, estos tipos ya son consistentes con /types/index.ts
 * y con el esquema SQL que se entregará en la Fase 4.
 */

export interface Database {
  public: {
    Tables: {
      users: {
        Row: {
          id: string;
          name: string;
          email: string;
          country: string;
          user_type:
            | "estudiante"
            | "jardinero"
            | "agricultor"
            | "huerta_familiar"
            | "otro";
          created_at: string;
        };
        Insert: {
          id: string;
          name: string;
          email: string;
          country: string;
          user_type:
            | "estudiante"
            | "jardinero"
            | "agricultor"
            | "huerta_familiar"
            | "otro";
          created_at?: string;
        };
        Update: Partial<Database["public"]["Tables"]["users"]["Insert"]>;
      };
      plants: {
        Row: {
          id: string;
          user_id: string;
          name: string;
          species: string | null;
          notes: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          name: string;
          species?: string | null;
          notes?: string | null;
          created_at?: string;
        };
        Update: Partial<Database["public"]["Tables"]["plants"]["Insert"]>;
      };
      scans: {
        Row: {
          id: string;
          user_id: string;
          plant_id: string | null;
          image_url: string;
          plant_name: string;
          scientific_name: string;
          diagnosis: string;
          category: string;
          confidence: number;
          severity: string;
          symptoms: string[];
          causes: string[];
          recommendations: string[];
          prevention: string[];
          is_demo_result: boolean;
          created_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          plant_id?: string | null;
          image_url: string;
          plant_name: string;
          scientific_name: string;
          diagnosis: string;
          category: string;
          confidence: number;
          severity: string;
          symptoms: string[];
          causes: string[];
          recommendations: string[];
          prevention: string[];
          is_demo_result?: boolean;
          created_at?: string;
        };
        Update: Partial<Database["public"]["Tables"]["scans"]["Insert"]>;
      };
    };
  };
}
