import { createBrowserClient } from "@supabase/ssr";
import type { Database } from "./database.types";

/**
 * Cliente de Supabase para Client Components (formularios, hooks, etc.).
 * Usa la clave anónima pública: es seguro exponerla en el navegador,
 * la seguridad real la garantiza Row Level Security (ver /database/schema.sql).
 */
export function createClient() {
  return createBrowserClient<Database>(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  );
}
