import { z } from "zod";

/**
 * Esquemas de validación para los formularios de autenticación.
 * Se usan tanto en el cliente (feedback inmediato) como en las
 * Server Actions (validación de seguridad real).
 */

export const userTypeOptions = [
  { value: "estudiante", label: "Estudiante" },
  { value: "jardinero", label: "Jardinero/a" },
  { value: "agricultor", label: "Agricultor/a" },
  { value: "huerta_familiar", label: "Huerta familiar" },
  { value: "otro", label: "Otro" },
] as const;

export const registerSchema = z
  .object({
    name: z
      .string()
      .trim()
      .min(2, "El nombre debe tener al menos 2 caracteres.")
      .max(80, "El nombre es demasiado largo."),
    email: z
      .string()
      .trim()
      .toLowerCase()
      .email("Ingresá un correo electrónico válido."),
    password: z
      .string()
      .min(8, "La contraseña debe tener al menos 8 caracteres.")
      .regex(/[A-Za-z]/, "La contraseña debe incluir al menos una letra.")
      .regex(/[0-9]/, "La contraseña debe incluir al menos un número."),
    confirmPassword: z.string(),
    country: z.string().trim().min(2, "Seleccioná tu país."),
    userType: z.enum([
      "estudiante",
      "jardinero",
      "agricultor",
      "huerta_familiar",
      "otro",
    ]),
  })
  .refine((data) => data.password === data.confirmPassword, {
    message: "Las contraseñas no coinciden.",
    path: ["confirmPassword"],
  });

export type RegisterInput = z.infer<typeof registerSchema>;

export const loginSchema = z.object({
  email: z.string().trim().toLowerCase().email("Ingresá un correo electrónico válido."),
  password: z.string().min(1, "Ingresá tu contraseña."),
});

export type LoginInput = z.infer<typeof loginSchema>;

export const resetPasswordSchema = z.object({
  email: z.string().trim().toLowerCase().email("Ingresá un correo electrónico válido."),
});

export type ResetPasswordInput = z.infer<typeof resetPasswordSchema>;
