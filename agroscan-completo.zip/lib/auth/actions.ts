"use server";

import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import {
  registerSchema,
  loginSchema,
  resetPasswordSchema,
} from "@/lib/auth/schemas";

export interface AuthActionState {
  success: boolean;
  message?: string;
  fieldErrors?: Record<string, string[]>;
}

/**
 * Mensajes de error genéricos y en español. Nunca exponemos el error
 * técnico interno de Supabase directamente al usuario (punto 32 del
 * prompt maestro: "Nunca mostrar errores técnicos internos al usuario").
 */
function friendlyAuthError(rawMessage: string): string {
  const msg = rawMessage.toLowerCase();
  if (msg.includes("invalid login credentials")) {
    return "El correo electrónico o la contraseña son incorrectos.";
  }
  if (msg.includes("already registered") || msg.includes("already exists")) {
    return "Ya existe una cuenta registrada con ese correo electrónico.";
  }
  if (msg.includes("email not confirmed")) {
    return "Debés confirmar tu correo electrónico antes de iniciar sesión. Revisá tu bandeja de entrada.";
  }
  if (msg.includes("rate limit")) {
    return "Demasiados intentos. Esperá unos minutos antes de volver a intentarlo.";
  }
  return "Ocurrió un error inesperado. Intentá nuevamente en unos instantes.";
}

// ---------------------------------------------------------------------------
// REGISTRO
// ---------------------------------------------------------------------------

export async function signUpAction(
  _prevState: AuthActionState,
  formData: FormData
): Promise<AuthActionState> {
  const raw = {
    name: formData.get("name"),
    email: formData.get("email"),
    password: formData.get("password"),
    confirmPassword: formData.get("confirmPassword"),
    country: formData.get("country"),
    userType: formData.get("userType"),
  };

  const parsed = registerSchema.safeParse(raw);
  if (!parsed.success) {
    return {
      success: false,
      fieldErrors: parsed.error.flatten().fieldErrors as Record<string, string[]>,
    };
  }

  const { name, email, password, country, userType } = parsed.data;
  const supabase = createClient();

  const { data, error } = await supabase.auth.signUp({
    email,
    password,
    options: {
      // Se guarda en user_metadata; el perfil definitivo en la tabla "users"
      // se crea mediante un trigger de base de datos (ver /database/schema.sql, Fase 4).
      data: { name, country, user_type: userType },
      emailRedirectTo: `${process.env.NEXT_PUBLIC_APP_URL}/auth/callback`,
    },
  });

  if (error) {
    return { success: false, message: friendlyAuthError(error.message) };
  }

  // Si Supabase requiere confirmación de correo, no hay sesión todavía.
  if (data.user && !data.session) {
    return {
      success: true,
      message:
        "¡Cuenta creada! Te enviamos un correo de confirmación. Revisá tu bandeja de entrada para activar tu cuenta.",
    };
  }

  revalidatePath("/", "layout");
  redirect("/dashboard");
}

// ---------------------------------------------------------------------------
// INICIO DE SESIÓN
// ---------------------------------------------------------------------------

export async function signInAction(
  _prevState: AuthActionState,
  formData: FormData
): Promise<AuthActionState> {
  const raw = {
    email: formData.get("email"),
    password: formData.get("password"),
  };

  const parsed = loginSchema.safeParse(raw);
  if (!parsed.success) {
    return {
      success: false,
      fieldErrors: parsed.error.flatten().fieldErrors as Record<string, string[]>,
    };
  }

  const supabase = createClient();
  const { error } = await supabase.auth.signInWithPassword(parsed.data);

  if (error) {
    return { success: false, message: friendlyAuthError(error.message) };
  }

  revalidatePath("/", "layout");

  const redirectTo = (formData.get("redirect") as string) || "/dashboard";
  redirect(redirectTo);
}

// ---------------------------------------------------------------------------
// CERRAR SESIÓN
// ---------------------------------------------------------------------------

export async function signOutAction() {
  const supabase = createClient();
  await supabase.auth.signOut();
  revalidatePath("/", "layout");
  redirect("/");
}

// ---------------------------------------------------------------------------
// RECUPERAR CONTRASEÑA
// ---------------------------------------------------------------------------

export async function resetPasswordAction(
  _prevState: AuthActionState,
  formData: FormData
): Promise<AuthActionState> {
  const parsed = resetPasswordSchema.safeParse({
    email: formData.get("email"),
  });

  if (!parsed.success) {
    return {
      success: false,
      fieldErrors: parsed.error.flatten().fieldErrors as Record<string, string[]>,
    };
  }

  const supabase = createClient();
  const { error } = await supabase.auth.resetPasswordForEmail(parsed.data.email, {
    redirectTo: `${process.env.NEXT_PUBLIC_APP_URL}/auth/actualizar-password`,
  });

  if (error) {
    return { success: false, message: friendlyAuthError(error.message) };
  }

  return {
    success: true,
    message:
      "Si el correo está registrado, te enviamos un enlace para restablecer tu contraseña.",
  };
}
