/**
 * Utilidades generales compartidas por AgroScan.
 */

/** Combina clases condicionalmente (envoltorio simple sin dependencias extra). */
export function cn(...classes: Array<string | false | null | undefined>): string {
  return classes.filter(Boolean).join(" ");
}

/** Formatea una fecha ISO al formato es-AR legible, ej: "12 de agosto de 2026". */
export function formatDate(isoDate: string): string {
  return new Date(isoDate).toLocaleDateString("es-AR", {
    day: "numeric",
    month: "long",
    year: "numeric",
  });
}

/** Traduce la severidad a una etiqueta y color de acento consistentes en toda la app. */
export function severityMeta(severity: "baja" | "media" | "alta" | "desconocida") {
  const map = {
    baja: { label: "Baja", color: "text-agro-600 bg-agro-100" },
    media: { label: "Media", color: "text-earth-700 bg-earth-100" },
    alta: { label: "Alta", color: "text-red-700 bg-red-100" },
    desconocida: { label: "Desconocida", color: "text-gray-600 bg-gray-100" },
  } as const;
  return map[severity];
}
