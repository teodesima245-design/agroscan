import type { AIAnalysisResult } from "@/types";

/**
 * Casos de demostración fijos (punto 25 del prompt maestro).
 * Se usan en dos lugares:
 *   1. El proveedor "demo" de la IA (services/ai/providers/demo.ts),
 *      cuando AI_API_PROVIDER=demo (por defecto, ya que AgroScan es
 *      100% gratuito y esto evita depender de una clave de pago).
 *   2. El Demo Mode público (Fase 11), para mostrar AgroScan en una
 *      feria de ciencias sin necesidad de conexión a una IA real.
 *
 * Todos estos resultados tienen isDemoResult: true y NUNCA se presentan
 * como si fueran un análisis real (punto 25: "No presentar datos
 * ficticios como si fueran resultados reales de IA").
 */

export interface DemoCase {
  id: string;
  label: string;
  result: AIAnalysisResult;
}

export const demoCases: DemoCase[] = [
  {
    id: "tomate",
    label: "🍅 Tomate",
    result: {
      plant: { name: "Tomate", scientificName: "Solanum lycopersicum", confidence: 0.94 },
      diagnosis: {
        category: "enfermedad",
        name: "Tizón temprano (Alternaria solani)",
        confidence: 0.87,
        severity: "media",
      },
      symptoms: [
        "Manchas circulares marrones con anillos concéntricos en las hojas inferiores",
        "Amarillamiento del tejido alrededor de las manchas",
        "Caída progresiva de hojas viejas",
      ],
      possibleCauses: [
        "Hongo que se desarrolla en condiciones de humedad prolongada",
        "Riego por aspersión que moja el follaje",
        "Poca circulación de aire entre plantas",
      ],
      recommendations: [
        "Retirar y eliminar las hojas afectadas de forma responsable",
        "Regar directamente en la base de la planta, evitando mojar las hojas",
        "Mejorar el espacio entre plantas para favorecer la ventilación",
        "Aplicar un fungicida a base de cobre si el problema persiste, siguiendo las instrucciones oficiales del producto",
      ],
      prevention: [
        "Rotar los cultivos de tomate cada temporada",
        "Regar temprano en la mañana para que el follaje seque rápido",
        "Desinfectar las herramientas de poda entre plantas",
      ],
      warnings: [],
      isDemoResult: true,
    },
  },
  {
    id: "lechuga",
    label: "🥬 Lechuga",
    result: {
      plant: { name: "Lechuga", scientificName: "Lactuca sativa", confidence: 0.91 },
      diagnosis: {
        category: "plaga",
        name: "Pulgón (Aphididae)",
        confidence: 0.82,
        severity: "baja",
      },
      symptoms: [
        "Pequeños insectos verdes agrupados en el envés de las hojas jóvenes",
        "Hojas ligeramente enrolladas o deformadas",
        "Presencia de sustancia pegajosa (melaza) sobre las hojas",
      ],
      possibleCauses: [
        "Clima cálido y seco favorable para la reproducción de pulgones",
        "Ausencia de insectos benéficos que los controlen naturalmente",
      ],
      recommendations: [
        "Retirar los pulgones manualmente o con un chorro de agua",
        "Introducir o atraer controladores biológicos como mariquitas",
        "Aplicar una solución de agua con jabón potásico sobre las zonas afectadas",
      ],
      prevention: [
        "Revisar las plantas regularmente para detectar plagas a tiempo",
        "Evitar el exceso de fertilizante nitrogenado, que atrae pulgones",
        "Mantener plantas compañeras que repelan pulgones, como la caléndula",
      ],
      warnings: [],
      isDemoResult: true,
    },
  },
  {
    id: "albahaca",
    label: "🌿 Albahaca",
    result: {
      plant: { name: "Albahaca", scientificName: "Ocimum basilicum", confidence: 0.96 },
      diagnosis: {
        category: "planta_saludable",
        name: "Sin problemas detectados",
        confidence: 0.9,
        severity: "desconocida",
      },
      symptoms: ["Follaje verde intenso y uniforme", "Sin manchas ni deformaciones visibles"],
      possibleCauses: [],
      recommendations: [
        "Continuar con el riego regular, manteniendo el sustrato húmedo pero no encharcado",
        "Cosechar las hojas superiores regularmente para estimular el crecimiento",
      ],
      prevention: [
        "Ubicarla en un lugar con buena luz solar directa",
        "Evitar el riego sobre las hojas para prevenir hongos",
      ],
      warnings: [],
      isDemoResult: true,
    },
  },
  {
    id: "rosal",
    label: "🌹 Rosal",
    result: {
      plant: { name: "Rosal", scientificName: "Rosa spp.", confidence: 0.89 },
      diagnosis: {
        category: "enfermedad",
        name: "Oídio (Podosphaera pannosa)",
        confidence: 0.79,
        severity: "media",
      },
      symptoms: [
        "Capa blanquecina y polvorienta en hojas y brotes tiernos",
        "Hojas jóvenes deformadas o enroscadas",
        "Detención del crecimiento en los brotes afectados",
      ],
      possibleCauses: [
        "Hongo favorecido por noches frescas y días cálidos con poca ventilación",
        "Exceso de humedad ambiental combinado con sombra parcial",
      ],
      recommendations: [
        "Podar y eliminar de forma responsable las partes muy afectadas",
        "Mejorar la ventilación alrededor de la planta",
        "Aplicar bicarbonato de sodio diluido en agua como tratamiento preventivo suave",
      ],
      prevention: [
        "Evitar el riego por aspersión sobre el follaje",
        "Espaciar bien los rosales al plantarlos",
        "Desinfectar las tijeras de poda entre plantas",
      ],
      warnings: [],
      isDemoResult: true,
    },
  },
];

/** Devuelve un caso de demostración de forma determinística a partir de un texto (por ejemplo, la ruta de la imagen). */
export function pickDemoCase(seed: string): DemoCase {
  let hash = 0;
  for (let i = 0; i < seed.length; i++) {
    hash = (hash * 31 + seed.charCodeAt(i)) >>> 0;
  }
  return demoCases[hash % demoCases.length];
}
