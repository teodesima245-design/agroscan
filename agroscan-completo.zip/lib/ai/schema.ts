import { z } from "zod";

/**
 * Esquema de validación del resultado de la IA.
 * NINGÚN resultado se muestra al usuario sin pasar por este esquema
 * (punto 14 del prompt maestro: "Validar la respuesta antes de mostrarla").
 * Si un proveedor de IA devuelve algo mal formado, se descarta el
 * resultado y se le informa al usuario que no se pudo completar el
 * análisis, en lugar de mostrar datos parciales o inventados.
 */

const diagnosisCategorySchema = z.enum([
  "enfermedad",
  "plaga",
  "deficiencia_nutricional",
  "estres_ambiental",
  "daño_fisico",
  "planta_saludable",
  "desconocido",
]);

const severityLevelSchema = z.enum(["baja", "media", "alta", "desconocida"]);

export const aiAnalysisResultSchema = z.object({
  plant: z.object({
    name: z.string().min(1).max(120),
    scientificName: z.string().max(160),
    confidence: z.number().min(0).max(1),
  }),
  diagnosis: z.object({
    category: diagnosisCategorySchema,
    name: z.string().min(1).max(160),
    confidence: z.number().min(0).max(1),
    severity: severityLevelSchema,
  }),
  symptoms: z.array(z.string().min(1)).max(20),
  possibleCauses: z.array(z.string().min(1)).max(20),
  recommendations: z.array(z.string().min(1)).max(20),
  prevention: z.array(z.string().min(1)).max(20),
  warnings: z.array(z.string().min(1)).max(10),
  isDemoResult: z.boolean(),
});

export type ValidatedAIAnalysisResult = z.infer<typeof aiAnalysisResultSchema>;

/** Umbral por debajo del cual se le avisa al usuario que el análisis no es confiable (punto 17). */
export const LOW_CONFIDENCE_THRESHOLD = 0.45;
