import { z } from "zod";

export const plantSchema = z.object({
  name: z
    .string()
    .trim()
    .min(1, "Ponele un nombre a tu planta.")
    .max(80, "El nombre es demasiado largo."),
  species: z.string().trim().max(120, "El texto es demasiado largo.").optional(),
  notes: z.string().trim().max(2000, "Las notas son demasiado largas.").optional(),
});

export type PlantInput = z.infer<typeof plantSchema>;
