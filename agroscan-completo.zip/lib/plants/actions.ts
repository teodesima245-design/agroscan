"use server";

import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { plantSchema } from "@/lib/plants/schemas";

export interface PlantActionState {
  success: boolean;
  message?: string;
  fieldErrors?: Record<string, string[]>;
}

// ---------------------------------------------------------------------------
// CREAR PLANTA
// ---------------------------------------------------------------------------

export async function createPlantAction(
  _prevState: PlantActionState,
  formData: FormData
): Promise<PlantActionState> {
  const raw = {
    name: formData.get("name"),
    species: formData.get("species") || undefined,
    notes: formData.get("notes") || undefined,
  };

  const parsed = plantSchema.safeParse(raw);
  if (!parsed.success) {
    return { success: false, fieldErrors: parsed.error.flatten().fieldErrors as Record<string, string[]> };
  }

  const supabase = createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    return { success: false, message: "Tu sesión expiró. Volvé a iniciar sesión." };
  }

  const { error } = await supabase.from("plants").insert({
    user_id: user.id,
    name: parsed.data.name,
    species: parsed.data.species ?? null,
    notes: parsed.data.notes ?? null,
  });

  if (error) {
    return { success: false, message: "No pudimos guardar la planta. Intentá nuevamente." };
  }

  revalidatePath("/mis-plantas");
  return { success: true };
}

// ---------------------------------------------------------------------------
// EDITAR PLANTA
// ---------------------------------------------------------------------------

export async function updatePlantAction(
  plantId: string,
  _prevState: PlantActionState,
  formData: FormData
): Promise<PlantActionState> {
  const raw = {
    name: formData.get("name"),
    species: formData.get("species") || undefined,
    notes: formData.get("notes") || undefined,
  };

  const parsed = plantSchema.safeParse(raw);
  if (!parsed.success) {
    return { success: false, fieldErrors: parsed.error.flatten().fieldErrors as Record<string, string[]> };
  }

  const supabase = createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    return { success: false, message: "Tu sesión expiró. Volvé a iniciar sesión." };
  }

  const { error } = await supabase
    .from("plants")
    .update({
      name: parsed.data.name,
      species: parsed.data.species ?? null,
      notes: parsed.data.notes ?? null,
    })
    .eq("id", plantId)
    .eq("user_id", user.id);

  if (error) {
    return { success: false, message: "No pudimos actualizar la planta. Intentá nuevamente." };
  }

  revalidatePath("/mis-plantas");
  return { success: true };
}

// ---------------------------------------------------------------------------
// ELIMINAR PLANTA
// ---------------------------------------------------------------------------

export interface DeletePlantResult {
  success: boolean;
  message?: string;
}

/**
 * Elimina una planta. Los análisis asociados NO se borran (la relación en
 * "scans" está definida como on delete set null, ver /database/schema.sql):
 * el usuario conserva su historial completo, solo pierde la asociación
 * con esta planta puntual.
 */
export async function deletePlantAction(plantId: string): Promise<DeletePlantResult> {
  const supabase = createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    return { success: false, message: "Tu sesión expiró. Volvé a iniciar sesión." };
  }

  const { error } = await supabase
    .from("plants")
    .delete()
    .eq("id", plantId)
    .eq("user_id", user.id);

  if (error) {
    return { success: false, message: "No pudimos eliminar la planta. Intentá nuevamente." };
  }

  revalidatePath("/mis-plantas");
  revalidatePath("/historial");
  return { success: true };
}

// ---------------------------------------------------------------------------
// LISTAR PLANTAS DEL USUARIO (para el selector del escáner)
// ---------------------------------------------------------------------------

export async function getUserPlantsAction() {
  const supabase = createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) return [];

  const { data } = await supabase
    .from("plants")
    .select("id, name, species")
    .order("created_at", { ascending: false });

  return data ?? [];
}
