"use server";

import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { analyzePlantImage, AIAnalysisError } from "@/services/ai";
import { STORAGE_BUCKET } from "@/lib/constants";
import type { AIAnalysisResult } from "@/types";

export interface CreateScanResult {
  success: boolean;
  scanId?: string;
  result?: AIAnalysisResult;
  message?: string;
}

/**
 * Orquesta el flujo completo de un análisis (Fases 5, 6 y 7 conectadas):
 *   1. Genera una URL firmada de la imagen ya subida a Storage.
 *   2. Llama a analyzePlantImage() (arquitectura modular de IA).
 *   3. Guarda el resultado validado en la tabla "scans".
 *
 * Se ejecuta en el servidor para que AI_API_KEY nunca quede expuesta al
 * navegador (punto 31 del prompt maestro).
 */
export async function createScanAction(
  imagePath: string,
  plantId: string | null
): Promise<CreateScanResult> {
  const supabase = createClient();

  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    return { success: false, message: "Tu sesión expiró. Volvé a iniciar sesión." };
  }

  // 1. URL firmada temporal para que el proveedor de IA pueda descargar la imagen.
  const { data: signedUrlData, error: signedUrlError } = await supabase.storage
    .from(STORAGE_BUCKET)
    .createSignedUrl(imagePath, 300); // 5 minutos, tiempo de sobra para el análisis

  if (signedUrlError || !signedUrlData) {
    return {
      success: false,
      message: "No pudimos acceder a la imagen subida. Intentá escanear nuevamente.",
    };
  }

  // 2. Análisis de IA (punto 43: preferimos "no estamos seguros" antes que inventar).
  let result;
  try {
    result = await analyzePlantImage(signedUrlData.signedUrl);
  } catch (err) {
    if (err instanceof AIAnalysisError) {
      return {
        success: false,
        message:
          "No pudimos completar el análisis de tu planta en este momento. Intentá nuevamente en unos instantes.",
      };
    }
    return { success: false, message: "Ocurrió un error inesperado durante el análisis." };
  }

  // 3. Guardar el resultado en la tabla "scans" (protegida por RLS: el
  // usuario solo puede insertar filas con su propio user_id).
  const { data: scan, error: insertError } = await supabase
    .from("scans")
    .insert({
      user_id: user.id,
      plant_id: plantId,
      image_url: imagePath,
      plant_name: result.plant.name,
      scientific_name: result.plant.scientificName,
      diagnosis: result.diagnosis.name,
      category: result.diagnosis.category,
      confidence: result.diagnosis.confidence,
      severity: result.diagnosis.severity,
      symptoms: result.symptoms,
      causes: result.possibleCauses,
      recommendations: result.recommendations,
      prevention: result.prevention,
      is_demo_result: result.isDemoResult,
    })
    .select("id")
    .single();

  if (insertError || !scan) {
    return {
      success: false,
      message: "El análisis se completó, pero no pudimos guardarlo. Intentá nuevamente.",
    };
  }

  return { success: true, scanId: scan.id, result };
}

// ---------------------------------------------------------------------------
// ELIMINAR ANÁLISIS (Fase 8 — Mi historial)
// ---------------------------------------------------------------------------

export interface DeleteScanResult {
  success: boolean;
  message?: string;
}

/**
 * Elimina un análisis del historial. RLS garantiza que un usuario solo
 * pueda borrar sus propios escaneos (punto 20 del prompt maestro), pero
 * igual se filtra explícitamente por user_id como defensa adicional.
 * También intenta borrar la imagen asociada en Storage para no dejar
 * archivos huérfanos.
 */
export async function deleteScanAction(scanId: string): Promise<DeleteScanResult> {
  const supabase = createClient();

  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    return { success: false, message: "Tu sesión expiró. Volvé a iniciar sesión." };
  }

  const { data: scan } = await supabase
    .from("scans")
    .select("image_url")
    .eq("id", scanId)
    .eq("user_id", user.id)
    .single();

  const { error } = await supabase
    .from("scans")
    .delete()
    .eq("id", scanId)
    .eq("user_id", user.id);

  if (error) {
    return { success: false, message: "No pudimos eliminar el análisis. Intentá nuevamente." };
  }

  if (scan?.image_url) {
    await supabase.storage.from(STORAGE_BUCKET).remove([scan.image_url]);
  }

  revalidatePath("/historial");
  return { success: true };
}
