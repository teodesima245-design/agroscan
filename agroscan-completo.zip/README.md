# 🌱 AgroScan: Guardianes Ecológicos

> "Escaneá. Detectá. Protegé."

**Estado del proyecto: Fases 1, 2, 3 y 4 completadas — Arquitectura, frontend, autenticación y base de datos.**

Este README se irá completando en cada fase de desarrollo. La documentación
completa (instalación, Supabase, IA, testing, deploy, etc.) se agregará en la
fase final, según lo planificado:

- [x] Fase 1 — Arquitectura y estructura del proyecto
- [x] Fase 2 — Frontend y diseño (landing, login, registro, dashboard, escáner, perfil)
- [x] Fase 3 — Autenticación (Supabase Auth: registro, login, logout, recuperar contraseña, rutas protegidas)
- [x] Fase 4 — Base de datos (tablas, RLS, trigger de perfil automático — ver `/database`)
- [x] Fase 5 — Carga y almacenamiento de imágenes (Supabase Storage, validación, bucket privado)
- [x] Fase 6 — Integración de IA (arquitectura modular `analyzePlantImage()`, proveedores demo/Hugging Face/Plant.id, validación de respuesta)
- [x] Fase 7 — Resultados (página dedicada `/resultado/[id]` con las 6 secciones del análisis y avisos de transparencia)
- [x] Fase 8 — Historial (búsqueda, filtro por severidad y eliminación de análisis)
- [x] Fase 9 — Mis plantas (alta, edición, eliminación y asociación de análisis)
- [x] Fase 10 — Código QR (usa `NEXT_PUBLIC_APP_URL`, nunca hardcodeado)
- [x] Fase 11 — Demo Mode (`/demo`, público, sin necesidad de cuenta ni de IA real)
- [x] Fase 12 — Testing (Vitest: esquemas de validación, respuesta de IA, casos de demo — ver `/tests/README.md` para el alcance exacto)
- [x] Fase 13 — Deploy (ver sección "Deploy en Vercel" más abajo)

**Las 13 fases del prompt maestro están completas.** AgroScan es un
prototipo funcional real, no una descripción de cómo construirlo.
- [ ] Fase 4 — Base de datos
- [ ] Fase 5 — Carga y almacenamiento de imágenes
- [ ] Fase 6 — Integración de IA
- [ ] Fase 7 — Resultados
- [ ] Fase 8 — Historial
- [ ] Fase 9 — Mis plantas
- [ ] Fase 10 — Código QR
- [ ] Fase 11 — Demo Mode
- [ ] Fase 12 — Testing
- [ ] Fase 13 — Deploy

## Instalación rápida (una vez descargado el proyecto)

```bash
npm install
cp .env.example .env.local
# completar .env.local con tus credenciales de Supabase (ver abajo)
npm run dev
```

La app quedará disponible en `http://localhost:3000`.

## Configuración de Supabase (necesaria para que la autenticación funcione)

1. Creá un proyecto gratuito en [supabase.com](https://supabase.com).
2. En **Project Settings → API**, copiá:
   - `Project URL` → pegalo en `NEXT_PUBLIC_SUPABASE_URL`
   - `anon public key` → pegalo en `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - `service_role key` → pegalo en `SUPABASE_SERVICE_ROLE_KEY` (¡nunca la subas a git ni la expongas en el frontend!)
3. En **Authentication → URL Configuration**, agregá `http://localhost:3000/auth/callback`
   como Redirect URL (y la URL de producción cuando la tengas).
4. En **SQL Editor**, ejecutá el contenido completo de `/database/schema.sql`.
   Esto crea las tablas `users`, `plants` y `scans`, activa Row Level Security
   y configura el trigger que completa automáticamente el perfil del usuario
   al registrarse. Más detalle en `/database/README.md`.
5. En **SQL Editor**, ejecutá también `/database/storage-policies.sql`.
   Esto crea el bucket privado `plant-images` (10MB máx. por imagen, solo
   JPG/PNG/WEBP) y sus políticas de seguridad: cada usuario solo puede
   subir, ver y borrar las imágenes dentro de su propia carpeta
   (`{user_id}/...`). Podés confirmar que se creó en **Storage** en el
   panel de Supabase.

## Configuración de IA

AgroScan usa una arquitectura modular: toda la app llama siempre a una
única función, `analyzePlantImage()` (`/services/ai/index.ts`), que
internamente delega en el proveedor configurado en `AI_API_PROVIDER`.

| Proveedor | Requiere clave | Costo | Cuándo usarlo |
|---|---|---|---|
| `demo` (por defecto) | No | Gratis siempre | Probar la app, presentaciones, feria de ciencias |
| `huggingface` | Sí (gratis) | Límite mensual gratuito | Clasificación real con un modelo abierto |
| `plantid` | Sí (gratis con límite) | Límite mensual gratuito | Diagnóstico especializado más preciso |
| `custom` | Depende de vos | — | Conectar tu propio modelo (por ejemplo, tu clasificador TensorFlow Lite de AgroScan) |

Para cambiar de proveedor, solo hace falta editar `.env.local`:
```
AI_API_PROVIDER=huggingface
AI_API_KEY=tu_token_aqui
```
Ningún otro archivo necesita modificarse — el escáner, los resultados y
el historial ya están conectados a `analyzePlantImage()` sin importar qué
proveedor esté activo.

## Generación del código QR

La página `/compartir` genera un código QR con `qrcode.react` que apunta a
`NEXT_PUBLIC_APP_URL`. Recordá actualizar esa variable cuando despliegues a
producción (ver `.env.example`) — en desarrollo apunta a `localhost:3000`,
que no sirve para escanear desde otro dispositivo en una feria de ciencias.

## Rutas ya disponibles

| Ruta | Descripción | Protegida |
|---|---|---|
| `/` | Landing page | No |
| `/login` | Inicio de sesión | No |
| `/registro` | Registro de usuario | No |
| `/recuperar-password` | Recuperar contraseña | No |
| `/auth/callback` | Confirmación de email de Supabase | No |
| `/dashboard` | Panel principal | Sí |
| `/escanear` | Escáner de plantas (sube imagen, ejecuta la IA y redirige al resultado) | Sí |
| `/resultado/[id]` | Resultado detallado de un análisis | Sí |
| `/historial` | Búsqueda, filtro y eliminación de análisis anteriores. Acepta `?planta={id}` para ver solo los análisis de una planta puntual | Sí |
| `/mis-plantas` | Alta, edición y eliminación de plantas | Sí |
| `/compartir` | Código QR para compartir AgroScan (feria de ciencias, difusión) | Sí |
| `/perfil` | Perfil del usuario | Sí |
| `/demo` | Demo Mode con 4 casos predefinidos, sin necesidad de cuenta | No |

Las rutas protegidas redirigen automáticamente a `/login` si no hay sesión
activa (ver `middleware.ts`).

## Stack tecnológico

- **Frontend:** Next.js 14 (App Router) + React + TypeScript + Tailwind CSS
- **Backend:** Server Actions / API Routes de Next.js
- **Base de datos y Auth:** Supabase (PostgreSQL + Supabase Auth)
- **Almacenamiento:** Supabase Storage
- **IA:** arquitectura modular intercambiable (ver `/services/ai`, se implementa en Fase 6)
- **QR:** `qrcode.react` (se implementa en Fase 10)

## Estructura del proyecto

```
agroscan/
├── app/            # Rutas y páginas (Next.js App Router)
├── components/     # Componentes de UI reutilizables
├── lib/            # Utilidades, validaciones (Zod) y Server Actions
├── services/       # Lógica de negocio: IA (services/ai) y Storage (services/storage)
├── hooks/          # React hooks personalizados (useUser)
├── types/          # Tipos TypeScript del dominio
├── database/       # Esquema SQL, RLS y políticas de Storage
├── public/         # Archivos estáticos
├── styles/         # Estilos adicionales
├── tests/          # Pruebas automatizadas (Vitest) — ver tests/README.md
├── vitest.config.ts
├── middleware.ts
├── .env.example
└── package.json
```

## Testing

```bash
npm test
```

Ver `/tests/README.md` para el detalle de qué está cubierto por pruebas
automáticas (validaciones, respuesta de IA, casos de demo) y qué requiere
pruebas manuales o un proyecto de Supabase de testing separado (RLS,
creación/eliminación real de análisis).

## Deploy en Vercel

AgroScan está pensado para desplegarse gratis en Vercel:

1. Subí el proyecto a un repositorio de GitHub (o GitLab/Bitbucket).
2. Entrá a [vercel.com](https://vercel.com) → **Add New → Project** → importá el repositorio.
   Vercel detecta Next.js automáticamente, no hace falta configurar nada del build.
3. En **Environment Variables**, cargá las mismas variables de tu `.env.local`:
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - `SUPABASE_SERVICE_ROLE_KEY`
   - `AI_API_PROVIDER` (y `AI_API_KEY` si no usás `demo`)
   - `NEXT_PUBLIC_APP_URL` → poné la URL que Vercel te va a asignar (por
     ejemplo `https://agroscan.vercel.app`), o tu dominio propio si tenés uno.
   - `NEXT_PUBLIC_DEMO_MODE=true`
4. Hacé clic en **Deploy**.
5. Una vez desplegado, volvé a Supabase → **Authentication → URL
   Configuration** y agregá tu URL de producción + `/auth/callback` como
   Redirect URL (el mismo paso que hiciste con `localhost` en la Fase 3).
6. Volvé a Vercel y actualizá `NEXT_PUBLIC_APP_URL` si el dominio final
   quedó distinto al que pusiste en el paso 3 — esto es importante porque
   el código QR de `/compartir` (Fase 10) depende de esta variable.

Con esto, cada vez que subas cambios a la rama principal del repositorio,
Vercel va a desplegar la nueva versión automáticamente.

## Mejoras futuras

La arquitectura de AgroScan quedó preparada para incorporar, sin romper
nada de lo ya construido:

- Más especies, enfermedades y plagas en la base de conocimiento de los
  proveedores de IA (`/services/ai/providers`)
- Detección de múltiples problemas en una misma fotografía
- Análisis de varias fotografías de una misma planta en un solo escaneo
- Información climática y calendarios agrícolas regionales
- Verificación de diagnósticos por especialistas humanos
- Modelos de IA propios y especializados (por ejemplo, un clasificador
  TensorFlow Lite entrenado específicamente para AgroScan)
- Aplicación móvil nativa (Android/iOS)
- Funcionamiento parcial offline (PWA)
- Paginación en el historial para cuentas con muchos análisis
- Foto de portada por planta en "Mis plantas"

## Principio fundamental

> "La inteligencia artificial ayuda a identificar posibles problemas, pero no
> reemplaza a un profesional agrícola."

100% gratuita. Sin planes premium, sin publicidad, sin pagos.
