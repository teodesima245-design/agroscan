import { createClient } from "@/lib/supabase/server";
import DashboardHeader from "@/components/dashboard/DashboardHeader";
import { Mail, MapPin, Tag } from "lucide-react";

export const metadata = { title: "Mi perfil — AgroScan" };

const userTypeLabels: Record<string, string> = {
  estudiante: "Estudiante",
  jardinero: "Jardinero/a",
  agricultor: "Agricultor/a",
  huerta_familiar: "Huerta familiar",
  otro: "Otro",
};

export default async function PerfilPage() {
  const supabase = createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  const displayName =
    (user?.user_metadata?.name as string | undefined) ??
    user?.email?.split("@")[0] ??
    "Guardián/a";
  const country = (user?.user_metadata?.country as string | undefined) ?? "—";
  const userType = (user?.user_metadata?.user_type as string | undefined) ?? "otro";

  return (
    <>
      <DashboardHeader userName={displayName} />
      <main className="flex-1 bg-agro-50/40 px-4 py-10 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-xl">
          <h1 className="font-display text-2xl font-bold text-agro-900">Mi perfil</h1>

          <div className="card mt-6 p-6">
            <div className="flex items-center gap-4">
              <span className="flex h-16 w-16 items-center justify-center rounded-full bg-agro-100 text-2xl font-bold text-agro-600">
                {displayName.charAt(0).toUpperCase()}
              </span>
              <div>
                <p className="font-display text-lg font-bold text-agro-900">{displayName}</p>
                <p className="text-sm text-agro-800/60">
                  {userTypeLabels[userType] ?? "Otro"}
                </p>
              </div>
            </div>

            <dl className="mt-6 flex flex-col gap-4 border-t border-agro-100 pt-6">
              <div className="flex items-center gap-3">
                <Mail size={18} className="text-agro-500" aria-hidden="true" />
                <dt className="sr-only">Correo electrónico</dt>
                <dd className="text-sm text-agro-800">{user?.email}</dd>
              </div>
              <div className="flex items-center gap-3">
                <MapPin size={18} className="text-agro-500" aria-hidden="true" />
                <dt className="sr-only">País</dt>
                <dd className="text-sm text-agro-800">{country}</dd>
              </div>
              <div className="flex items-center gap-3">
                <Tag size={18} className="text-agro-500" aria-hidden="true" />
                <dt className="sr-only">Tipo de usuario</dt>
                <dd className="text-sm text-agro-800">
                  {userTypeLabels[userType] ?? "Otro"}
                </dd>
              </div>
            </dl>
          </div>

          <p className="mt-4 text-center text-xs text-agro-800/50">
            La edición de perfil y la eliminación de cuenta se habilitan en
            próximas fases, junto con la sección de privacidad.
          </p>
        </div>
      </main>
    </>
  );
}
