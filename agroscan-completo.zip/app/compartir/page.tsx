import { createClient } from "@/lib/supabase/server";
import DashboardHeader from "@/components/dashboard/DashboardHeader";
import QRShare from "@/components/share/QRShare";

export const metadata = { title: "Compartí AgroScan" };

export default async function CompartirPage() {
  const supabase = createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  const displayName =
    (user?.user_metadata?.name as string | undefined) ??
    user?.email?.split("@")[0] ??
    "Guardián/a";

  // NUNCA hardcodeado para producción: viene de la variable de entorno
  // NEXT_PUBLIC_APP_URL (punto 24 del prompt maestro).
  const appUrl = process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000";

  return (
    <>
      <DashboardHeader userName={displayName} />
      <main className="flex-1 bg-agro-50/40 px-4 py-10 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-3xl text-center">
          <h1 className="font-display text-2xl font-bold text-agro-900 sm:text-3xl">
            Compartí AgroScan
          </h1>
          <p className="mt-2 text-agro-800/70">
            Mostrá este código en tu feria de ciencias o compartilo con quien
            quiera conocer el proyecto.
          </p>
        </div>

        <div className="mt-10">
          <QRShare appUrl={appUrl} />
        </div>
      </main>
    </>
  );
}
