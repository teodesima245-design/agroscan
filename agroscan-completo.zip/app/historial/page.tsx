import { createClient } from "@/lib/supabase/server";
import { STORAGE_BUCKET } from "@/lib/constants";
import DashboardHeader from "@/components/dashboard/DashboardHeader";
import HistorialList from "@/components/historial/HistorialList";
import type { Scan } from "@/types";

export const metadata = { title: "Mi historial — AgroScan" };

interface PageProps {
  searchParams: { planta?: string };
}

export default async function HistorialPage({ searchParams }: PageProps) {
  const supabase = createClient();

  const {
    data: { user },
  } = await supabase.auth.getUser();

  const displayName =
    (user?.user_metadata?.name as string | undefined) ??
    user?.email?.split("@")[0] ??
    "Guardián/a";

  let query = supabase.from("scans").select("*").order("created_at", { ascending: false });

  let filteredPlantName: string | null = null;
  if (searchParams.planta) {
    query = query.eq("plant_id", searchParams.planta);
    const { data: plant } = await supabase
      .from("plants")
      .select("name")
      .eq("id", searchParams.planta)
      .single();
    filteredPlantName = plant?.name ?? null;
  }

  const { data: rawScans } = await query;

  // Generamos una URL firmada por imagen (el bucket es privado). Como el
  // historial de un usuario típico no tiene miles de escaneos, resolver
  // esto en el servidor con Promise.all es simple y suficientemente rápido.
  const scans: (Scan & { thumbnailUrl: string | null })[] = await Promise.all(
    (rawScans ?? []).map(async (row) => {
      const { data: signed } = await supabase.storage
        .from(STORAGE_BUCKET)
        .createSignedUrl(row.image_url, 3600);

      return {
        id: row.id,
        userId: row.user_id,
        plantId: row.plant_id,
        imageUrl: row.image_url,
        plantName: row.plant_name,
        scientificName: row.scientific_name,
        diagnosisCategory: row.category,
        diagnosisName: row.diagnosis,
        confidence: row.confidence,
        severity: row.severity,
        symptoms: row.symptoms ?? [],
        causes: row.causes ?? [],
        recommendations: row.recommendations ?? [],
        prevention: row.prevention ?? [],
        isDemoResult: row.is_demo_result,
        createdAt: row.created_at,
        thumbnailUrl: signed?.signedUrl ?? null,
      };
    })
  );

  return (
    <>
      <DashboardHeader userName={displayName} />
      <main className="flex-1 bg-agro-50/40 px-4 py-10 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-5xl">
          <h1 className="font-display text-2xl font-bold text-agro-900 sm:text-3xl">
            {filteredPlantName ? `Historial de ${filteredPlantName}` : "Mi historial"}
          </h1>
          <p className="mt-2 text-agro-800/70">
            {filteredPlantName
              ? "Todos los análisis realizados sobre esta planta."
              : "Todos los análisis que realizaste, en un solo lugar."}
          </p>

          <div className="mt-8">
            <HistorialList scans={scans} />
          </div>
        </div>
      </main>
    </>
  );
}
