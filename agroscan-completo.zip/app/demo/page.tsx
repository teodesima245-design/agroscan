import Header from "@/components/Header";
import Footer from "@/components/Footer";
import DemoModeView from "@/components/demo/DemoModeView";

export const metadata = { title: "Demo Mode — AgroScan" };

/**
 * Demo Mode (punto 25 del prompt maestro): permite mostrar AgroScan en
 * una exposición escolar sin necesidad de cuenta, conexión a Supabase ni
 * a ninguna IA real. Por eso esta ruta NO está en la lista de rutas
 * protegidas del middleware (ver /middleware.ts).
 */
export default function DemoPage() {
  return (
    <>
      <Header />
      <main className="flex-1 bg-agro-50/40 px-4 py-12 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-3xl text-center">
          <h1 className="font-display text-2xl font-bold text-agro-900 sm:text-3xl">
            Demo Mode
          </h1>
          <p className="mt-2 text-agro-800/70">
            Elegí un caso para ver cómo se ve un análisis en AgroScan, sin
            necesidad de cuenta ni de una fotografía real.
          </p>
        </div>

        <div className="mt-10">
          <DemoModeView />
        </div>
      </main>
      <Footer />
    </>
  );
}
