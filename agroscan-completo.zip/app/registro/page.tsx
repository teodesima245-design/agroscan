import Link from "next/link";
import { Leaf } from "lucide-react";
import RegisterForm from "@/components/auth/RegisterForm";

export const metadata = { title: "Crear cuenta — AgroScan" };

export default function RegisterPage() {
  return (
    <main className="flex flex-1 items-center justify-center bg-agro-50/50 px-4 py-12">
      <div className="w-full max-w-md">
        <Link href="/" className="mb-8 flex items-center justify-center gap-2 text-agro-700 font-display font-bold text-xl">
          <span className="flex h-10 w-10 items-center justify-center rounded-xl2 bg-agro-500 text-white">
            <Leaf size={22} aria-hidden="true" />
          </span>
          AgroScan
        </Link>

        <div className="card p-8">
          <h1 className="font-display text-2xl font-bold text-agro-900 text-center">
            Crear cuenta
          </h1>
          <p className="mt-2 text-center text-sm text-agro-800/70">
            100% gratis. Sin tarjetas, sin suscripciones.
          </p>

          <div className="mt-8">
            <RegisterForm />
          </div>
        </div>
      </div>
    </main>
  );
}
