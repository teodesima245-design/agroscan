import { notFound } from "next/navigation";
import Link from "next/link";
import {
  Sparkles,
  ScanLine,
  History,
  AlertTriangle,
  Leaf,
  Search,
  Gauge,
  Eye,
  Brain,
  Sprout,
  ShieldCheck,
} from "lucide-react";
import { createClient } from "@/lib/supabase/server";
import { STORAGE_BUCKET } from "@/lib/constants";
import { severityMeta, formatDate } from "@/lib/utils";
import DashboardHeader from "@/components/dashboard/DashboardHeader";
import type { SeverityLevel } from "@/types";

export const metadata = { title: "Resultado del análisis — AgroScan" };

const LOW_CONFIDENCE_THRESHOLD = 0.45;

interface PageProps {
  params: { id: string };
}

export default async function ResultadoPage({ params }: PageProps) {
  const supabase = createClient();

  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    notFound();
  }

  // RLS garantiza que esta consulta solo devuelva el escaneo si pertenece
  // al usuario autenticado; si es de otra persona, simplemente no aparece.
  const { data: scan, error } = await supabase
    .from("scans")
    .select("*")
    .eq("id", params.id)
    .single();

  if (error || !scan) {
    notFound();
  }

  const { data: signedUrlData } = await supabase.storage
    .from(STORAGE_BUCKET)
    .createSignedUrl(scan.image_url, 3600);

  const displayName =
    (user.user_metadata?.name as string | undefined) ?? user.email?.split("@")[0] ?? "Guardián/a";

  const severity = severityMeta(scan.severity as SeverityLevel);
  const confidencePercent = Math.round(scan.confidence * 100);
  const isLowConfidence = scan.confidence < LOW_CONFIDENCE_THRESHOLD && scan.category !== "planta_saludable";

  return (
    <>
      <DashboardHeader userName={displayName} />
      <main className="flex-1 bg-agro-50/40 px-4 py-10 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-3xl">
          <div className="flex items-center justify-between">
            <h1 className="font-display text-2xl font-bold text-agro-900 sm:text-3xl">
              Resultado del análisis
            </h1>
            <span className="text-xs text-agro-800/50">{formatDate(scan.created_at)}</span>
          </div>

          {scan.is_demo_result && (
            <div className="mt-4 flex items-center gap-2 rounded-xl2 bg-earth-100 px-4 py-2 text-sm font-bold uppercase tracking-wide text-earth-700">
              <Sparkles size={16} aria-hidden="true" />
              Resultado de demostración — no proviene de un análisis real de IA
            </div>
          )}

          {/* Imagen analizada */}
          {signedUrlData?.signedUrl && (
            <div className="mt-6 overflow-hidden rounded-xl2 border border-agro-100">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={signedUrlData.signedUrl}
                alt={`Fotografía analizada de ${scan.plant_name}`}
                className="aspect-video w-full object-cover sm:aspect-[21/9]"
              />
            </div>
          )}

          {/* 🌱 Planta identificada */}
          <section className="card mt-6 p-6">
            <SectionHeader icon={Leaf} title="Planta identificada" />
            <p className="mt-2 font-display text-xl font-bold text-agro-900">{scan.plant_name}</p>
            {scan.scientific_name && (
              <p className="text-sm italic text-agro-800/60">{scan.scientific_name}</p>
            )}
          </section>

          {/* 🔎 Posible problema */}
          <section className="card mt-4 p-6">
            <SectionHeader icon={Search} title="Posible problema" />
            <p className="mt-2 font-display text-xl font-bold text-agro-900">{scan.diagnosis}</p>
            <p className="mt-1 text-xs text-agro-800/50">
              Este es un posible diagnóstico generado por inteligencia artificial, no un
              diagnóstico definitivo.
            </p>
          </section>

          {/* 📊 Severidad y confianza */}
          <section className="card mt-4 p-6">
            <SectionHeader icon={Gauge} title="Severidad" />
            <div className="mt-3 flex flex-wrap items-center gap-2">
              <span className={`rounded-full px-4 py-1.5 text-sm font-bold ${severity.color}`}>
                {severity.label}
              </span>
              <span className="rounded-full bg-tech-100 px-4 py-1.5 text-sm font-bold text-tech-700">
                Confianza: {confidencePercent}%
              </span>
            </div>

            {isLowConfidence && (
              <div
                role="alert"
                className="mt-4 flex items-start gap-2 rounded-xl2 border border-earth-400/40 bg-earth-50 px-4 py-3 text-sm text-earth-700"
              >
                <AlertTriangle size={18} className="mt-0.5 shrink-0" aria-hidden="true" />
                El análisis no es suficientemente confiable. Intentá realizar otra fotografía
                o consultá con un profesional especializado.
              </div>
            )}
          </section>

          {/* 👀 Síntomas observados */}
          {scan.symptoms?.length > 0 && (
            <section className="card mt-4 p-6">
              <SectionHeader icon={Eye} title="Síntomas observados" />
              <ul className="mt-2 list-disc space-y-1 pl-5 text-sm text-agro-800/80">
                {scan.symptoms.map((s: string, i: number) => (
                  <li key={i}>{s}</li>
                ))}
              </ul>
            </section>
          )}

          {/* 🧠 Posibles causas */}
          {scan.causes?.length > 0 && (
            <section className="card mt-4 p-6">
              <SectionHeader icon={Brain} title="Posibles causas" />
              <ul className="mt-2 list-disc space-y-1 pl-5 text-sm text-agro-800/80">
                {scan.causes.map((c: string, i: number) => (
                  <li key={i}>{c}</li>
                ))}
              </ul>
            </section>
          )}

          {/* 🌿 Recomendaciones */}
          {scan.recommendations?.length > 0 && (
            <section className="card mt-4 p-6">
              <SectionHeader icon={Sprout} title="Recomendaciones" />
              <ul className="mt-2 list-disc space-y-1 pl-5 text-sm text-agro-800/80">
                {scan.recommendations.map((r: string, i: number) => (
                  <li key={i}>{r}</li>
                ))}
              </ul>
            </section>
          )}

          {/* 🛡️ Prevención */}
          {scan.prevention?.length > 0 && (
            <section className="card mt-4 p-6">
              <SectionHeader icon={ShieldCheck} title="Prevención" />
              <ul className="mt-2 list-disc space-y-1 pl-5 text-sm text-agro-800/80">
                {scan.prevention.map((p: string, i: number) => (
                  <li key={i}>{p}</li>
                ))}
              </ul>
            </section>
          )}

          {/* Aviso general sobre la IA (punto 36) */}
          <div
            role="note"
            className="mt-6 rounded-xl2 border border-agro-200 bg-agro-50 px-5 py-4 text-xs text-agro-800/70"
          >
            AgroScan utiliza inteligencia artificial para generar estimaciones orientativas a
            partir de imágenes. Los resultados pueden contener errores y no constituyen un
            diagnóstico profesional. Ante problemas graves o dudas, consultá a un profesional
            especializado.
          </div>

          <div className="mt-8 flex flex-col gap-3 sm:flex-row">
            <Link href="/escanear" className="btn-tech flex-1">
              <ScanLine size={20} aria-hidden="true" />
              Escanear otra planta
            </Link>
            <Link href="/historial" className="btn-secondary flex-1">
              <History size={20} aria-hidden="true" />
              Ver mi historial
            </Link>
          </div>
        </div>
      </main>
    </>
  );
}

function SectionHeader({
  icon: Icon,
  title,
}: {
  icon: React.ComponentType<{ size?: number; className?: string; "aria-hidden"?: boolean }>;
  title: string;
}) {
  return (
    <div className="flex items-center gap-2 text-agro-800/60">
      <Icon size={16} aria-hidden="true" />
      <p className="text-sm font-semibold uppercase tracking-wide">{title}</p>
    </div>
  );
}
