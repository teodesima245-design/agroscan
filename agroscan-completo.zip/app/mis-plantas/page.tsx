import { createClient } from "@/lib/supabase/server";
import DashboardHeader from "@/components/dashboard/DashboardHeader";
import PlantsManager from "@/components/plants/PlantsManager";
import type { Plant } from "@/types";

export const metadata = { title: "Mis plantas — AgroScan" };

export default async function MisPlantasPage() {
  const supabase = createClient();

  const {
    data: { user },
  } = await supabase.auth.getUser();

  const displayName =
    (user?.user_metadata?.name as string | undefined) ??
    user?.email?.split("@")[0] ??
    "Guardián/a";

  const { data: rawPlants } = await supabase
    .from("plants")
    .select("*")
    .order("created_at", { ascending: false });

  const { data: rawScans } = await supabase.from("scans").select("plant_id");

  const scanCountByPlant = new Map<string, number>();
  (rawScans ?? []).forEach((s) => {
    if (!s.plant_id) return;
    scanCountByPlant.set(s.plant_id, (scanCountByPlant.get(s.plant_id) ?? 0) + 1);
  });

  const plants: (Plant & { scanCount: number })[] = (rawPlants ?? []).map((p) => ({
    id: p.id,
    userId: p.user_id,
    name: p.name,
    species: p.species,
    notes: p.notes,
    createdAt: p.created_at,
    scanCount: scanCountByPlant.get(p.id) ?? 0,
  }));

  return (
    <>
      <DashboardHeader userName={displayName} />
      <main className="flex-1 bg-agro-50/40 px-4 py-10 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-4xl">
          <h1 className="font-display text-2xl font-bold text-agro-900 sm:text-3xl">
            Mis plantas
          </h1>
          <p className="mt-2 text-agro-800/70">
            Organizá tus plantas y seguí la evolución de cada una a lo largo del tiempo.
          </p>

          <div className="mt-8">
            <PlantsManager plants={plants} />
          </div>
        </div>
      </main>
    </>
  );
}
