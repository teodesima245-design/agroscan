import { createClient } from "@/lib/supabase/server";
import DashboardHeader from "@/components/dashboard/DashboardHeader";
import PlantScanner from "@/components/scanner/PlantScanner";

export const metadata = { title: "Escanear planta — AgroScan" };

export default async function EscanearPage() {
  const supabase = createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  const displayName =
    (user?.user_metadata?.name as string | undefined) ??
    user?.email?.split("@")[0] ??
    "Guardián/a";

  return (
    <>
      <DashboardHeader userName={displayName} />
      <main className="flex-1 bg-agro-50/40 px-4 py-10 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-3xl text-center">
          <h1 className="font-display text-2xl font-bold text-agro-900 sm:text-3xl">
            Escanear planta
          </h1>
          <p className="mt-2 text-agro-800/70">
            Tomá una fotografía clara y bien iluminada de la parte afectada de
            la planta para obtener el mejor resultado.
          </p>
        </div>

        <div className="mt-10">
          <PlantScanner />
        </div>
      </main>
    </>
  );
}
