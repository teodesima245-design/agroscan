import type { Metadata, Viewport } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "AgroScan: Guardianes Ecológicos",
  description:
    "Detectá problemas en tus plantas con inteligencia artificial. Subí una fotografía y AgroScan analizará posibles enfermedades, plagas y síntomas para ayudarte a cuidarla.",
  keywords: [
    "agroscan",
    "plantas",
    "inteligencia artificial",
    "agricultura",
    "detección de enfermedades",
    "huerta",
    "américa latina",
  ],
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: "#4a9c3d",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="es" className="h-full">
      <body className="h-full min-h-screen flex flex-col">{children}</body>
    </html>
  );
}
