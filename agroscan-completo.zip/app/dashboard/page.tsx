import { ScanLine, History, Sprout, User as UserIcon, QrCode } from "lucide-react";
import { createClient } from "@/lib/supabase/server";
import DashboardHeader from "@/components/dashboard/DashboardHeader";
import ActionCard from "@/components/dashboard/ActionCard";

export const metadata = { title: "Panel — AgroScan" };

/**
 * NOTA sobre las estadísticas: hasta que la Fase 4 (base de datos) y la
 * Fase 8 (historial) estén implementadas, las estadísticas se muestran
 * en cero. La estructura de consulta ya queda preparada para conectarse
 * directamente a la tabla "scans" en cuanto exista.
 */
export default async function DashboardPage() {
  const supabase = createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  const displayName =
    (user?.user_metadata?.name as string | undefined) ??
    user?.email?.split("@")[0] ??
    "Guardián/a";

  // Placeholder de estadísticas — se reemplaza por consultas reales a "scans" en la Fase 8.
  const stats = [
    { label: "Plantas analizadas", value: "0" },
    { label: "Cantidad de escaneos", value: "0" },
    { label: "Último análisis", value: "—" },
    { label: "Problemas detectados", value: "0" },
  ];

  return (
    <>
      <DashboardHeader userName={displayName} />
      <main className="flex-1 bg-agro-50/40">
        <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
          <h1 className="font-display text-2xl font-bold text-agro-900 sm:text-3xl">
            Hola, {displayName}. ¿Qué planta querés analizar hoy?
          </h1>

          <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
            <ActionCard
              href="/escanear"
              icon={ScanLine}
              title="Escanear planta"
              description="Fotografiá o subí una imagen para analizarla."
              accent="tech"
            />
            <ActionCard
              href="/historial"
              icon={History}
              title="Mi historial"
              description="Consultá tus análisis anteriores."
              accent="agro"
            />
            <ActionCard
              href="/mis-plantas"
              icon={Sprout}
              title="Mis plantas"
              description="Organizá y seguí la evolución de tus plantas."
              accent="earth"
            />
            <ActionCard
              href="/compartir"
              icon={QrCode}
              title="Compartir AgroScan"
              description="Generá un código QR para mostrar el proyecto."
              accent="tech"
            />
            <ActionCard
              href="/perfil"
              icon={UserIcon}
              title="Mi perfil"
              description="Actualizá tus datos personales."
              accent="agro"
            />
          </div>

          <section className="mt-12" aria-labelledby="stats-heading">
            <h2 id="stats-heading" className="font-display text-lg font-bold text-agro-900">
              Tu actividad
            </h2>
            <div className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              {stats.map((stat) => (
                <div key={stat.label} className="card p-5">
                  <p className="text-2xl font-bold text-agro-700">{stat.value}</p>
                  <p className="mt-1 text-sm text-agro-800/70">{stat.label}</p>
                </div>
              ))}
            </div>
          </section>
        </div>
      </main>
    </>
  );
}
